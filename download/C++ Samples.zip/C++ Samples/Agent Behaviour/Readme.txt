AgentBehaviour

Seek/Flee:
Vehicles move toward the cursor.
Vehicles move away from the cursor.

Arrive:
Vehicles move toward the cursor. Arrival behaviour implemented within cursor radius.

Wander:
Vehicles move in a controlled random manner utilising wander movement.

Avoid:
Vehicles move away from the cursor when within their radius.

Singlefile/Scattered leader following:
A designated leader moves around with wandering behaviour. Any successive vehicle additions will seek the leader in a singlefile/scattered manner. Vehicles also avoid each other with the separation technique.


Controls:
F1 = Seek/Flee (Press again to alternate)
F2 = Arrive" << L"\n"
F3 = Wander" << L"\n"
F4 = Avoid" << L"\n"
F5 = Singlefile/Scattered following (Press again to alternate)

PLUS = Add vehicle
MINUS = Remove vehicle
ENTER = Enable/Disable vector components

TAB = Minimise/Maximise controls
SPACE = Restart application
ESCAPE = Close application