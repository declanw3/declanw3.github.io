#include "Utility.h"
#include "GameObject.h"

#ifndef _VEHICLE_H_
#define _VEHICLE_H_

typedef enum EComponents
{
	INVALID_COMPONENT = -1,

	COMPONENT_VELOCITY,
	COMPONENT_DESIRED,
	COMPONENT_STEERING,
	COMPONENT_WANDER,
	COMPONENT_DISPLACEMENT,
	COMPONENT_RADIUS,

	MAX_VECTORS
} EComponents;

typedef enum EBehaviours
{
	INVALID_BEHAVIOUR = -1,

	BEHAVIOUR_SEEK,
	BEHAVIOUR_FLEE,
	BEHAVIOUR_ARRIVE,
	BEHAVIOUR_WANDER,
	BEHAVIOUR_AVOID,
	BEHAVIOUR_LEAD_FOLLOW,

	MAX_BEHAVIOUR
} EBehaviours;

class Vehicle : public GameObject
{
public:
	Vehicle();
	~Vehicle();

	const bool InitialiseComponents(ID3D10Device* device);
	void Update(float dt);

	void SeekFlee(const D3DXVECTOR3& _vecTarget, EBehaviours _eActiveBehaviour);
	void Arrive(const D3DXVECTOR3& _vecTarget);
	void Wander();
	void Seperate(const D3DXVECTOR3& _vecTarget);
	void LeaderFollow(GameObject** _pVehicles, const int _iMaxVehicles);

	const float GetArrivalDist();
	void SetTarget(Vehicle* _pTarget);
	void SetVehicleID(const int _iVehicleID);
	const int GetVehicleID();
	void SetMaxVelocity(const float _fMaxVelocity);

protected:
private:

public:
protected:
private:
	D3DXVECTOR3 mVel;

	//SeekFlee
	float m_fMaxVelocity;
	float m_fMaxSteering;
	float m_fMass;

	//Arrival
	float m_fArrivalDist;

	//Wander
	float m_fWanderDistance;
	float m_fWanderRadius;
	float m_fWanderAngle;
	float m_fWanderChange;

	//Avoidance
	float m_fRadius;

	int m_iVehicleID;
	Vehicle* m_pTarget;
};

#endif //_VEHICLE_H_