#include "WindowApp.h"
#include "Camera.h"
#include "GameObject.h"
#include "Shape.h"
#include "Vehicle.h"
#include <ctime>
#include <sstream>

class SceneApp : public WindowApp
{
public:
	SceneApp(HINSTANCE hInstance);
	~SceneApp();

	void initApp();
	void onResize();
	void updateScene(float dt);
	void drawScene(); 

	void InitialiseGameObjects();
	void DeinitialiseGameObjects();
	void RecursiveDraw(GameObject* _pGameObject, const int _iPassCount, D3DXMATRIX* CameraViewMat, D3DXMATRIX* CameraProjMat);

	void AddVehicle();
	void RemoveVehicle();
	void SingleFile();
	void Scattered();

	LRESULT msgProc(UINT msg, WPARAM wParam, LPARAM lParam);

private:
	void buildFX();
	void buildVertexLayouts();
 
private:
	Camera mCamera;

	ID3D10Effect* mFX;
	ID3D10EffectTechnique* mTech;
	ID3D10InputLayout* mVertexLayout;
	ID3D10EffectMatrixVariable* mfxWVPVar;
	ID3D10EffectScalarVariable* mfxDeltaVar;
	ID3D10EffectMatrixVariable* mfxWorldVar;

	D3DXMATRIX mWVP;

	//Mouse position
	float mfMousePosX;
	float mfMousePosY;

	//Cube rotation
	bool	  mbUpArrow;
	bool	  mbDownArrow;
	bool	  mbLeftArrow;
	bool	  mbRightArrow;

	//Camera functionality
	bool	  mbMoveForward;
	bool	  mbMoveBack;
	bool	  mbMoveLeft;
	bool	  mbMoveRight;
	bool	  mbLookUp;
	bool	  mbLookDown;
	bool	  mbLookLeft;
	bool	  mbLookRight;
	bool	  mbAscend;
	bool	  mbDescend;
	bool	  mbRollRight;
	bool	  mbRollLeft;

	bool m_bDrawComponents;
	bool m_bSingleFile;

	int m_iMaxVehicles;
	GameObject** m_pVehicles;
	GameObject* m_pTestTarget;

	EBehaviours m_eActiveBehaviour;
};

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE prevInstance,
				   PSTR cmdLine, int showCmd)
{
	// Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif


	SceneApp theApp(hInstance);
	
	theApp.initApp();

 	return theApp.run();
}

SceneApp::SceneApp(HINSTANCE hInstance)
: WindowApp(hInstance)
, mFX(0)
, mTech(0)
, mVertexLayout(0)
, mfxWVPVar(0) 
, mfMousePosX(0.0f)
, mfMousePosY(0.0f)
, m_iMaxVehicles(0)
, m_pVehicles(0)
, m_pTestTarget(0)
{
	D3DXMatrixIdentity(&mWVP); 

	mfxDeltaVar = 0;

	//Booleans controlling arrow key presses
	mbUpArrow		= false;
	mbDownArrow		= false;
	mbLeftArrow		= false;
	mbRightArrow	= false;

	mbMoveForward	= false;
	mbMoveBack		= false;
	mbMoveLeft		= false;
	mbMoveRight		= false;
	mbLookUp		= false;
	mbLookDown		= false;
	mbLookLeft		= false;
	mbLookRight		= false;
	mbAscend		= false;
	mbDescend		= false;
	mbRollRight		= false;
	mbRollLeft		= false;

	m_bDrawComponents = true;
	m_bSingleFile = true;

	m_iMaxVehicles = 1;
	m_eActiveBehaviour = BEHAVIOUR_SEEK;
}

SceneApp::~SceneApp()
{
	if( md3dDevice )
		md3dDevice->ClearState();

	ReleaseCOM(mFX);
	ReleaseCOM(mVertexLayout);

	InitialiseGameObjects();
	DeinitialiseGameObjects();
}

void SceneApp::initApp()
{
	WindowApp::initApp();

	srand(static_cast<unsigned int>(time(0)));

	////Rasterizer state
	//D3D10_RASTERIZER_DESC rasterizerState;
	//rasterizerState.CullMode = D3D10_CULL_NONE;
	//rasterizerState.FillMode = D3D10_FILL_SOLID;
	//rasterizerState.FrontCounterClockwise = true;
	//rasterizerState.DepthBias = false;
	//rasterizerState.DepthBiasClamp = 0;
	//rasterizerState.SlopeScaledDepthBias = 0;
	//rasterizerState.DepthClipEnable = true;
	//rasterizerState.ScissorEnable = false;
	//rasterizerState.MultisampleEnable = false;
	//rasterizerState.AntialiasedLineEnable = true;
 //
	//ID3D10RasterizerState* pRS;
	//md3dDevice->CreateRasterizerState( &rasterizerState, &pRS);
	//md3dDevice->RSSetState(pRS);

	//Initialise GameObjects
	InitialiseGameObjects();

	buildFX();
	buildVertexLayouts();
}

void SceneApp::onResize()
{
	WindowApp::onResize();

	mCamera.CalculateProjMatrix(static_cast<float>(mClientWidth), 
								 static_cast<float>(mClientHeight));
}

void SceneApp::updateScene(float dt)
{
	WindowApp::updateScene(dt);

	if(mbMoveForward)	mCamera.Move(0.110f * dt);
	if(mbMoveBack)		mCamera.Move(-0.110f * dt);
	if(mbMoveLeft)		mCamera.Strafe(-0.110f * dt);
	if(mbMoveRight)		mCamera.Strafe(0.110f * dt);
	if(mbAscend)		mCamera.Fly(0.110f * dt);
	if(mbDescend)		mCamera.Fly(-0.110f * dt);

	if(mbLookLeft)		mCamera.Yaw(-0.003f * dt);
	if(mbLookRight)		mCamera.Yaw(0.003f * dt);
	if(mbLookUp)		mCamera.Pitch(-0.002f * dt);
	if(mbLookDown)		mCamera.Pitch(0.002f * dt);
	if(mbRollRight)		mCamera.Roll(-0.002f * dt);
	if(mbRollLeft)		mCamera.Roll(0.002f * dt);

	if(m_pVehicles != 0)
	{
		for(int i = 0; i < m_iMaxVehicles; ++i)
		{
			if(m_pVehicles[i] != 0)
			{
				Vehicle* vehicle = static_cast<Vehicle*>(m_pVehicles[i]);

				if(i == 0)
				{
					vehicle->SetMaxVelocity(200.0f);
				}

				if(m_pTestTarget != 0)
				{
					switch(m_eActiveBehaviour)
					{
					case BEHAVIOUR_SEEK:
						{
							vehicle->SeekFlee( *(m_pTestTarget->GetPosition()), m_eActiveBehaviour );
						}
						break;

					case BEHAVIOUR_FLEE:
						{
							vehicle->SeekFlee( *(m_pTestTarget->GetPosition()), m_eActiveBehaviour );
						}
						break;

					case BEHAVIOUR_ARRIVE:
						{
							vehicle->Arrive( *(m_pTestTarget->GetPosition()) );
						}
						break;

					case BEHAVIOUR_WANDER:
						{
							vehicle->Wander();
						}
						break;

					case BEHAVIOUR_AVOID:
						{
							vehicle->Seperate( *(m_pTestTarget->GetPosition()) );
						}
						break;

					case BEHAVIOUR_LEAD_FOLLOW:
						{
							//Leader
							if(i == 0)
							{
								vehicle->SetMaxVelocity(150.0f);
								vehicle->Wander();
								vehicle->Update(dt);
								continue;
							}

							vehicle->LeaderFollow(m_pVehicles, m_iMaxVehicles);
						}
						break;

						default:break;
					}
				}
				vehicle->Update(dt);
			}
		}
	}

	if(m_pTestTarget != 0)
	{
		Vehicle* target = static_cast<Vehicle*>(m_pTestTarget);
		target->Update(dt);
	}

	mCamera.Update(dt);

	if(m_bDrawText)
	{
		//std::wostringstream outs;   
		//outs.precision(6);
		//outs << L"Terrain width: " << mWidthInVerts << L"\n" 
		//		<< "Smoothing passes: " << mSmoothingPasses << L"\n\n"
		//		<< "ENTER = Subdivide terrain" << L"\n"
		//		<< "F1 = Smooth terrain" << L"\n";

		//mAppStats = outs.str();
	}
}

void SceneApp::drawScene()
{
	WindowApp::drawScene();

	// Restore default states, input layout and primitive topology 
	// because mFont->DrawText changes them.  Note that we can 
	// restore the default states by passing null.
	md3dDevice->OMSetDepthStencilState(0, 0);
	float blendFactors[] = {0.0f, 0.0f, 0.0f, 0.0f};
	md3dDevice->OMSetBlendState(0, blendFactors, 0xffffffff);

	//Send View/Proj matrices
	D3DXMATRIX CameraViewMat = *(mCamera.GetViewMatrix());
	D3DXMATRIX CameraProjMat = *(mCamera.GetProjMatrix());

	//Set vertex layout
    md3dDevice->IASetInputLayout(mVertexLayout);
	
	//Draw
    D3D10_TECHNIQUE_DESC techDesc;
    mTech->GetDesc( &techDesc );
    for(UINT p = 0; p < techDesc.Passes; ++p)
    {
		if(m_pVehicles != 0)
		{
			for(int i = 0; i < m_iMaxVehicles; ++i)
			{
				if(m_pVehicles[i] != 0)
				{
					RecursiveDraw(m_pVehicles[i], p, &CameraViewMat, &CameraProjMat);
				}
			}
		}

		if(m_pTestTarget != 0)
		{
			RecursiveDraw(m_pTestTarget, p, &CameraViewMat, &CameraProjMat);
		}
    }


	RECT R = {5, 5, 0, 0};
	mFont->DrawText(0, mFrameStats.c_str(), -1, &R, DT_NOCLIP, BLACK);

	if(m_bDrawText)
	{
		RECT R2 = {0, 0, mClientWidth, mClientHeight};
		mFont->DrawText(0, mAppStats.c_str(), -1, &R2, DT_NOCLIP | DT_RIGHT, BLACK);
	}

	mSwapChain->Present(0, 0);
}


void 
SceneApp::InitialiseGameObjects()
{
	if(m_pVehicles == 0)
	{
		m_pVehicles = new GameObject*[m_iMaxVehicles];
		if(m_pVehicles != 0)
		{
			for(int i = 0; i < m_iMaxVehicles; ++i)
			{
				m_pVehicles[i] = new Vehicle;
				if(m_pVehicles[i] != 0)
				{
					Vehicle* vehicle = static_cast<Vehicle*>(m_pVehicles[i]);

					vehicle->SetVehicleID(i);
					D3DXCOLOR color = D3DXCOLOR(0.0f, 0.0f, 0.0f, 0.0f);
					if(i == 0)
					{
						color = BLACK;
					}
					else
					{
						color = D3DXCOLOR(0.3f, 0.3f, 0.3f, 0.0f);
					}
					vehicle->InitialiseShape(md3dDevice, SHAPE_TRIANGLE, color);
					vehicle->InitialiseComponents(md3dDevice);
					vehicle->SetScale(20.0f);
				}
			}
		}
	}

	if(m_pTestTarget == 0)
	{
		m_pTestTarget = new Vehicle();
	}
	m_pTestTarget->InitialiseShape(md3dDevice, SHAPE_CIRCLE, MAGENTA);
	
	if(m_pVehicles[0] != 0)
	{
		Vehicle* vehicle = static_cast<Vehicle*>(m_pVehicles[0]);
		m_pTestTarget->SetScale(vehicle->GetArrivalDist());
	}
	else
	{
		m_pTestTarget->SetScale(10.0f);
	}

}

void 
SceneApp::DeinitialiseGameObjects()
{
	if(m_pVehicles != 0)
	{
		for(int i = 0; i < m_iMaxVehicles; ++i)
		{
			if(m_pVehicles[i] != 0)
			{
				delete m_pVehicles[i];
			}
		}

		delete[] m_pVehicles;
		m_pVehicles = 0;
	}

	if(m_pTestTarget != 0)
	{
		delete m_pTestTarget;
		m_pTestTarget = 0;
	}
}

void
SceneApp::RecursiveDraw(GameObject* _pGameObject, const int _iPassCount, D3DXMATRIX* CameraViewMat, D3DXMATRIX* CameraProjMat)
{					  
	if(_pGameObject != 0)
	{
		D3DXMATRIX GameObjectMat = *(_pGameObject->GetWorldMat());
		mWVP = GameObjectMat*(*(CameraViewMat) * *(CameraProjMat));
		mfxWVPVar->SetMatrix((float*)&mWVP);
		mTech->GetPassByIndex( _iPassCount )->Apply(0);
		_pGameObject->Draw(md3dDevice);

		if(m_bDrawComponents)
		{
			if(_pGameObject->HasComponents())
			{
				for(int i = 0; i < _pGameObject->GetMaxComponents(); ++i)
				{
					if(_pGameObject->GetComponent(i) != 0)
					{
						switch(m_eActiveBehaviour)
						{
						case BEHAVIOUR_SEEK:
							{
								if( (i != COMPONENT_VELOCITY) &&
									(i != COMPONENT_DESIRED) &&
									(i != COMPONENT_STEERING) )
								{
									continue;
								}
							}
							break;

						case BEHAVIOUR_FLEE:
							{
								if( (i != COMPONENT_VELOCITY) &&
									(i != COMPONENT_DESIRED) &&
									(i != COMPONENT_STEERING) )
								{
									continue;
								}
							}
							break;

						case BEHAVIOUR_ARRIVE:
							{
								if( (i != COMPONENT_VELOCITY) &&
									(i != COMPONENT_DESIRED) &&
									(i != COMPONENT_STEERING) )
								{
									continue;
								}
							}
							break;

						case BEHAVIOUR_WANDER:
							{
								if( (i != COMPONENT_VELOCITY) &&
									(i != COMPONENT_WANDER) &&
									(i != COMPONENT_DISPLACEMENT) )
								{
									continue;
								}
							}
							break;

						case BEHAVIOUR_AVOID:
							{
								if( (i != COMPONENT_VELOCITY) &&
									(i != COMPONENT_RADIUS) )
								{
									continue;
								}
							}
							break;

						case BEHAVIOUR_LEAD_FOLLOW:
							{
								if(_pGameObject != m_pVehicles[0])
								{
									if( (i == COMPONENT_WANDER) ||
										(i == COMPONENT_DISPLACEMENT) )
									{
										continue;
									}
								}
								else
								{
									if( (i == COMPONENT_DESIRED) ||
										(i == COMPONENT_STEERING) )
									{
										continue;
									}
								}
							}
							break;

							default:break;
						}
						RecursiveDraw(_pGameObject->GetComponent(i), _iPassCount, CameraViewMat, CameraProjMat);
					}
				}
			}
		}
	}
}

void 
SceneApp::AddVehicle()
{
	GameObject** newVehicles = new GameObject*[m_iMaxVehicles + 1];

	for(int i = 0; i < m_iMaxVehicles; ++i)
	{
		newVehicles[i] = m_pVehicles[i];
	}

	newVehicles[m_iMaxVehicles] = new Vehicle();
	Vehicle* vehicle = static_cast<Vehicle*>(newVehicles[m_iMaxVehicles]);

	vehicle->SetVehicleID(m_iMaxVehicles);
	vehicle->InitialiseShape(md3dDevice, SHAPE_TRIANGLE, D3DXCOLOR(0.3f, 0.3f, 0.3f, 0.0f));
	vehicle->InitialiseComponents(md3dDevice);
	vehicle->SetScale(20.0f);

	for(int i = 0; i < m_iMaxVehicles; ++i)
	{
		m_pVehicles[i] = 0;
	}
	delete[] m_pVehicles;
	m_pVehicles = 0;

	m_pVehicles = newVehicles;

	++m_iMaxVehicles;
}

void 
SceneApp::RemoveVehicle()
{
	if(m_iMaxVehicles > 1)
	{
		GameObject** newVehicles = new GameObject*[m_iMaxVehicles - 1];

		for(int i = 0; i < m_iMaxVehicles - 1; ++i)
		{
			newVehicles[i] = m_pVehicles[i];
		}

		if(m_pVehicles[m_iMaxVehicles - 1] != 0)
		{
			delete m_pVehicles[m_iMaxVehicles - 1];
			m_pVehicles[m_iMaxVehicles - 1] = 0;
		}

		for(int i = 0; i < m_iMaxVehicles; ++i)
		{
			m_pVehicles[i] = 0;
		}
		delete[] m_pVehicles;
		m_pVehicles = 0;

		m_pVehicles = newVehicles;

		--m_iMaxVehicles;
	}
}

void 
SceneApp::SingleFile()
{
	if(m_iMaxVehicles > 0)
	{
		if(m_pVehicles != 0)
		{
			for(int i = 0; i < m_iMaxVehicles; ++i)
			{
				if(i > 0)
				{
					if(m_pVehicles[i] != 0)
					{
						Vehicle* vehicle = static_cast<Vehicle*>(m_pVehicles[i]);
						Vehicle* target = static_cast<Vehicle*>(m_pVehicles[i - 1]);
						vehicle->SetTarget(target);
					}
				}
			}
		}
	}
}

void 
SceneApp::Scattered()
{
	if(m_iMaxVehicles > 0)
	{
		if(m_pVehicles != 0)
		{
			for(int i = 0; i < m_iMaxVehicles; ++i)
			{
				if(i > 0)
				{
					if(m_pVehicles[i] != 0)
					{
						Vehicle* vehicle = static_cast<Vehicle*>(m_pVehicles[i]);
						Vehicle* target = static_cast<Vehicle*>(m_pVehicles[0]);
						vehicle->SetTarget(target);
					}
				}
			}
		}
	}
}

LRESULT 
SceneApp::msgProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch( msg )
	{
	case WM_KEYUP:
		if(wParam == VK_UP)		mbUpArrow		= false;
		if(wParam == VK_DOWN)	mbDownArrow		= false;
		if(wParam == VK_LEFT)	mbLeftArrow		= false;
		if(wParam == VK_RIGHT)	mbRightArrow	= false;

		if(wParam == 'W')		mbMoveForward	= false;
		if(wParam == 'S')		mbMoveBack		= false;
		if(wParam == 'A')		mbMoveLeft		= false;
		if(wParam == 'D')		mbMoveRight		= false;
		if(wParam == 'R')		mbAscend		= false;
		if(wParam == 'F')		mbDescend		= false;
		if(wParam == 'I')		mbLookDown		= false;
		if(wParam == 'K')		mbLookUp		= false;
		if(wParam == 'J')		mbLookLeft		= false;
		if(wParam == 'L')		mbLookRight		= false;
		if(wParam == 'P')		mbRollLeft		= false;
		if(wParam == VK_OEM_1)	mbRollRight		= false;		
		return(0);

	case WM_KEYDOWN:
		//if(wParam == VK_UP)		mbUpArrow		= true;
		//if(wParam == VK_DOWN)	mbDownArrow		= true;
		//if(wParam == VK_LEFT)	mbLeftArrow		= true;
		//if(wParam == VK_RIGHT)	mbRightArrow	= true;

		//if(wParam == 'W')		mbMoveForward	= true;
		//if(wParam == 'S')		mbMoveBack		= true;
		//if(wParam == 'A')		mbMoveLeft		= true;
		//if(wParam == 'D')		mbMoveRight		= true;
		//if(wParam == 'R')		mbAscend		= true;
		//if(wParam == 'F')		mbDescend		= true;
		//if(wParam == 'I')		mbLookDown		= true;
		//if(wParam == 'K')		mbLookUp		= true;
		//if(wParam == 'J')		mbLookLeft		= true;
		//if(wParam == 'L')		mbLookRight		= true;
		//if(wParam == 'P')		mbRollLeft		= true;
		//if(wParam == VK_OEM_1)	mbRollRight		= true;	

		if(wParam == '1')	
		{

		}
		if(wParam == '2')	
		{

		}
		if(wParam == '3')	
		{

		}
		if(wParam == '9')	
		{

		}	
		if(wParam == '0')
		{

		}

		if(wParam == VK_OEM_MINUS)	
		{
			RemoveVehicle();
		}
		if(wParam == VK_OEM_PLUS)	
		{
			AddVehicle(); 
			
			if(m_bSingleFile)
			{
				SingleFile();	
			}
			else
			{
				Scattered();
			}			
		}


		if(wParam == VK_RETURN)
		{
			m_bDrawComponents = !m_bDrawComponents;	
		}
		if(wParam == VK_TAB)
		{
			m_bDrawText = !m_bDrawText;
		}

		if(wParam == VK_CLEAR)
		{

		}

		if(wParam == VK_F1)
		{
			if( (m_eActiveBehaviour != BEHAVIOUR_SEEK) && (m_eActiveBehaviour != BEHAVIOUR_FLEE))
			{
				m_eActiveBehaviour = BEHAVIOUR_SEEK;
				return(0);
			}
			if(m_eActiveBehaviour == BEHAVIOUR_SEEK)
			{
				m_eActiveBehaviour = BEHAVIOUR_FLEE;
			}
			else if(m_eActiveBehaviour == BEHAVIOUR_FLEE)
			{
				m_eActiveBehaviour = BEHAVIOUR_SEEK;
			}
		}
		if(wParam == VK_F2)
		{
			m_eActiveBehaviour = BEHAVIOUR_ARRIVE;
		}
		if(wParam == VK_F3)
		{
			m_eActiveBehaviour = BEHAVIOUR_WANDER;
		}
		if(wParam == VK_F4)
		{
			m_eActiveBehaviour = BEHAVIOUR_AVOID;
		}
		if(wParam == VK_F5)
		{
			if(m_eActiveBehaviour == BEHAVIOUR_LEAD_FOLLOW)
			{
				if(m_bSingleFile)
				{
					Scattered();
				}
				else
				{
					SingleFile();
				}
				m_bSingleFile = !m_bSingleFile;
			}

			m_eActiveBehaviour = BEHAVIOUR_LEAD_FOLLOW;
		}

		if(wParam == VK_F9)
		{
			
		}

		if(wParam == VK_ESCAPE) PostQuitMessage(0);
		if(wParam == VK_SPACE)  
		{
			DeinitialiseGameObjects();
			m_iMaxVehicles = 1;
			InitialiseGameObjects();

			mCamera.ResetCamera();	
		}
		return(0);

	case WM_MOUSEMOVE:
		{
		mfMousePosX = LOWORD(lParam); 
		mfMousePosY = HIWORD(lParam); 

		float fWorldX = mfMousePosX - (mClientWidth / 2) + mCamera.GetPos()->x;
		float fWorldY = mfMousePosY - (mClientHeight / 2) + mCamera.GetPos()->y;
		if(m_pTestTarget != 0)
		{
			m_pTestTarget->SetPosition( D3DXVECTOR3(fWorldX, -fWorldY, 0.0f) );
		}
		}
		return(0);

	case WM_LBUTTONDOWN:
		{
		float fWorldX = mfMousePosX - (mClientWidth / 2) + mCamera.GetPos()->x;
		float fWorldY = mfMousePosY - (mClientHeight / 2) + mCamera.GetPos()->y;
		if(m_pTestTarget != 0)
		{
		m_pTestTarget->SetPosition( D3DXVECTOR3(fWorldX, -fWorldY, 0.0f) );
		}
		}
		
		return(0);

	// WM_ACTIVATE is sent when the window is activated or deactivated.  
	// We pause the game when the window is deactivated and unpause it 
	// when it becomes active.  
	case WM_ACTIVATE:
		if( LOWORD(wParam) == WA_INACTIVE )
		{
			mAppPaused = true;
			mTimer.stop();
		}
		else
		{
			mAppPaused = false;
			mTimer.start();
		}
		return 0;

	// WM_SIZE is sent when the user resizes the window.  
	case WM_SIZE:
		// Save the new client area dimensions.
		mClientWidth  = LOWORD(lParam);
		mClientHeight = HIWORD(lParam);
		if( md3dDevice )
		{
			if( wParam == SIZE_MINIMIZED )
			{
				mAppPaused = true;
				mMinimized = true;
				mMaximized = false;
			}
			else if( wParam == SIZE_MAXIMIZED )
			{
				mAppPaused = false;
				mMinimized = false;
				mMaximized = true;
				onResize();
			}
			else if( wParam == SIZE_RESTORED )
			{
				
				// Restoring from minimized state?
				if( mMinimized )
				{
					mAppPaused = false;
					mMinimized = false;
					onResize();
				}

				// Restoring from maximized state?
				else if( mMaximized )
				{
					mAppPaused = false;
					mMaximized = false;
					onResize();
				}
				else if( mResizing )
				{
					// If user is dragging the resize bars, we do not resize 
					// the buffers here because as the user continuously 
					// drags the resize bars, a stream of WM_SIZE messages are
					// sent to the window, and it would be pointless (and slow)
					// to resize for each WM_SIZE message received from dragging
					// the resize bars.  So instead, we reset after the user is 
					// done resizing the window and releases the resize bars, which 
					// sends a WM_EXITSIZEMOVE message.
				}
				else // API call such as SetWindowPos or mSwapChain->SetFullscreenState.
				{
					onResize();
				}
			}
		}
		return 0;

	// WM_EXITSIZEMOVE is sent when the user grabs the resize bars.
	case WM_ENTERSIZEMOVE:
		mAppPaused = true;
		mResizing  = true;
		mTimer.stop();
		return 0;

	// WM_EXITSIZEMOVE is sent when the user releases the resize bars.
	// Here we reset everything based on the new window dimensions.
	case WM_EXITSIZEMOVE:
		mAppPaused = false;
		mResizing  = false;
		mTimer.start();
		onResize();
		return 0;
 
	// WM_DESTROY is sent when the window is being destroyed.
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;

	// The WM_MENUCHAR message is sent when a menu is active and the user presses 
	// a key that does not correspond to any mnemonic or accelerator key. 
	case WM_MENUCHAR:
        // Don't beep when we alt-enter.
        return MAKELRESULT(0, MNC_CLOSE);

	// Catch this message so to prevent the window from becoming too small.
	case WM_GETMINMAXINFO:
		((MINMAXINFO*)lParam)->ptMinTrackSize.x = 200;
		((MINMAXINFO*)lParam)->ptMinTrackSize.y = 200; 
		return 0;
	}

	return DefWindowProc(mhMainWnd, msg, wParam, lParam);
}

void SceneApp::buildFX()
{
	DWORD shaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
#if defined( DEBUG ) || defined( _DEBUG )
    shaderFlags |= D3D10_SHADER_DEBUG;
	shaderFlags |= D3D10_SHADER_SKIP_OPTIMIZATION;
#endif
 
	ID3D10Blob* compilationErrors = 0;
	HRESULT hr = 0;
	hr = D3DX10CreateEffectFromFile(L"Resources/color.fx", 0, 0, 
		"fx_4_0", shaderFlags, 0, md3dDevice, 0, 0, &mFX, &compilationErrors, 0);
	if(FAILED(hr))
	{
		if( compilationErrors )
		{
			MessageBoxA(0, (char*)compilationErrors->GetBufferPointer(), 0, 0);
			ReleaseCOM(compilationErrors);
		}
		DXTrace(__FILE__, (DWORD)__LINE__, hr, L"D3DX10CreateEffectFromFile", true);
	} 

	mTech = mFX->GetTechniqueByName("ColorTech");

	mfxWVPVar = mFX->GetVariableByName("gWVP")->AsMatrix();
	mfxDeltaVar = mFX->GetVariableByName("gDelta")->AsScalar();

	mfxWorldVar = mFX->GetVariableByName("gWorld")->AsMatrix();
}					  

void SceneApp::buildVertexLayouts()
{
	// Create the vertex input layout.
	D3D10_INPUT_ELEMENT_DESC vertexDesc[] =
	{
		{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0},
		{"COLOR",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 12, D3D10_INPUT_PER_VERTEX_DATA, 0}
	};

	// Create the input layout
    D3D10_PASS_DESC PassDesc;
    mTech->GetPassByIndex(0)->GetDesc(&PassDesc);
    HR(md3dDevice->CreateInputLayout(vertexDesc, 2, PassDesc.pIAInputSignature,
		PassDesc.IAInputSignatureSize, &mVertexLayout));
}
