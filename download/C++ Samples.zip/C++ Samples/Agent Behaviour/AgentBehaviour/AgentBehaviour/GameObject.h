#include "Utility.h"
#include "Shape.h"

#ifndef _GAMEOBJECT_H_
#define _GAMEOBJECT_H_

class GameObject
{
public:
	GameObject();
	~GameObject();

	const bool InitialiseShape(ID3D10Device* device, EShape _eShapeType, D3DXCOLOR _color = D3DXCOLOR(0.0f, 0.0f, 0.0f, 0.0f));
	virtual const bool InitialiseComponents(ID3D10Device* device);
	void Update(float dt);
	void Draw(ID3D10Device* device);

	const bool AddComponent(ID3D10Device* device, EShape _eShapeType, D3DXCOLOR _color = D3DXCOLOR(0.0f, 0.0f, 0.0f, 0.0f));
	GameObject* GetComponent(const int _iIndex);
	const bool HasComponents();
	const int GetMaxComponents();

	const D3DXMATRIX* GetWorldMat();
	void SetScale(const float _fScale);
	void SetRoll(const float _fRoll);

	const D3DXVECTOR3* GetPosition();
	void SetPosition(const D3DXVECTOR3& _vecPos);

protected:
private:

public:
protected:
	D3DXMATRIX mWorldMat;

	D3DXVECTOR3 mPos;
	D3DXVECTOR3 mDir;

	float mfYaw;
	float mfPitch;
	float mfRoll;

	float m_fScale;

	Shape* m_pShape;

	int m_iMaxComponents;
	GameObject** m_pComponents;

private:
};

#endif //_GAMEOBJECT_H_