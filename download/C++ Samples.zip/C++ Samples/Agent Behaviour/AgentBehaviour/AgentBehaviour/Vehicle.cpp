#include "Vehicle.h"

Vehicle::Vehicle()
: m_fMaxVelocity(0.0f)
, m_fMaxSteering(0.0f)
, m_fMass(0.0f)
, m_fArrivalDist(0.0f)
, m_fWanderDistance(0.0f)
, m_fWanderRadius(0.0f)
, m_fWanderAngle(0.0f)
, m_fWanderChange(0.0f)
, m_fRadius(0.0f)
, m_iVehicleID(0)
, m_pTarget(0)
{
	ZeroMemory(&mVel, sizeof(D3DXVECTOR3));

	m_fMaxVelocity = 200.0f;
	m_fMaxSteering = 0.125f;
	m_fMass = 0.0f;

	m_fArrivalDist = 100.0f;
	
	m_fWanderDistance = 20.0f;
	m_fWanderRadius = 20.0f;
	m_fWanderAngle = RandF(0.0f, 2*PI);
	m_fWanderChange = 0.5f;

	m_fRadius = 50.0f;
}

Vehicle::~Vehicle()
{

}

const bool
Vehicle::InitialiseComponents(ID3D10Device* device)
{
	bool bSuccess = false;

	AddComponent(device, SHAPE_LINE, RED);
	m_pComponents[COMPONENT_VELOCITY]->SetScale(100.0f);

	AddComponent(device, SHAPE_LINE, GREEN);
	m_pComponents[COMPONENT_DESIRED]->SetScale(100.0f);

	AddComponent(device, SHAPE_LINE, BLUE);
	m_pComponents[COMPONENT_STEERING]->SetScale(100.0f);


	AddComponent(device, SHAPE_CIRCLE, DARK_YELLOW_GREEN);
	m_pComponents[COMPONENT_WANDER]->SetScale(m_fWanderRadius * 2.0f);

	AddComponent(device, SHAPE_LINE, DARKBROWN);
	m_pComponents[COMPONENT_DISPLACEMENT]->SetScale(m_fWanderRadius * 2.0f);


	AddComponent(device, SHAPE_CIRCLE, BEACH_SAND);
	m_pComponents[COMPONENT_RADIUS]->SetScale(m_fRadius * 2.0f);

	return(bSuccess);
}

void 
Vehicle::Update(float dt)
{
	LimitVec3(mVel, m_fMaxVelocity);

	//Draw velocity vector
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_VELOCITY] != 0)
		{		
			if(D3DXVec3Length(&mVel) != 0)
			{
				float fAngle = 0.0f;
				if(D3DXVec3Length(&mVel) != 0)
				{
					fAngle = AngleBetweenVec3(D3DXVECTOR3(0.0f, 1.0f, 0.0f), mVel);
				}

				if(mVel.x < 0)
				{
					fAngle = (2 * PI) - fAngle;
				}
	
				m_pComponents[COMPONENT_VELOCITY]->SetRoll(-fAngle);
				m_pComponents[COMPONENT_VELOCITY]->SetPosition(mPos);

				//Display direction
				mfRoll = -fAngle;
			}
		}
	}

	mPos += mVel * dt;

	if(mPos.x > 400.0f)
	{
		mPos.x = -399.0f;
	}
	if(mPos.x < -400.0f)
	{
		mPos.x = 399.0f;
	}
	if(mPos.y > 300.0f)
	{
		mPos.y = -299.0f;	
	}
	if(mPos.y < -300.0f)
	{
		mPos.y = 299.0f;
	}

	GameObject::Update(dt);
}

void 
Vehicle::SeekFlee(const D3DXVECTOR3& _vecTarget, EBehaviours _eActiveBehaviour)
{
	//Calculate desired velocity
	D3DXVECTOR3 vecDesiredVelocity;
	ZeroMemory(&vecDesiredVelocity, sizeof(D3DXVECTOR3));

	switch(_eActiveBehaviour)
	{
	case BEHAVIOUR_SEEK:
		{
			D3DXVec3Normalize(&vecDesiredVelocity, &(_vecTarget - mPos));
		}
		break;

	case BEHAVIOUR_FLEE:
		{
			D3DXVec3Normalize(&vecDesiredVelocity, &(mPos - _vecTarget));
		}
		break;

		default:break;
	}
	D3DXVec3Scale(&vecDesiredVelocity, &vecDesiredVelocity, m_fMaxVelocity);

	//Draw desired vector
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_DESIRED] != 0)
		{		
			float fAngle = AngleBetweenVec3(D3DXVECTOR3(0.0f, 1.0f, 0.0f), vecDesiredVelocity);
			if(vecDesiredVelocity.x < 0)
			{
				fAngle = (2 * PI) - fAngle;
			}
	
			m_pComponents[COMPONENT_DESIRED]->SetRoll(-fAngle);
			m_pComponents[COMPONENT_DESIRED]->SetPosition(mPos);
		}
	}

	//Calculate steering force
	D3DXVECTOR3 vecSteering;
	ZeroMemory(&vecSteering, sizeof(D3DXVECTOR3));

	D3DXVec3Subtract(&vecSteering, &vecDesiredVelocity, &mVel);

	//Truncate
	LimitVec3(vecSteering, m_fMaxSteering);
	if(m_fMass != 0.0f)
	{
		D3DXVec3Scale(&vecSteering, &vecSteering, (1/m_fMass));
	}

	//Draw steering vector
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_STEERING] != 0)
		{		
			float fAngle = AngleBetweenVec3(D3DXVECTOR3(0.0f, 1.0f, 0.0f), vecSteering);
			if(vecSteering.x < 0)
			{
				fAngle = (2 * PI) - fAngle;
			}
	
			m_pComponents[COMPONENT_STEERING]->SetRoll(-fAngle);
			m_pComponents[COMPONENT_STEERING]->SetPosition(mPos);
		}
	}

	D3DXVec3Add(&mVel, &mVel, &vecSteering);
}

void 
Vehicle::Arrive(const D3DXVECTOR3& _vecTarget)
{
	//Calculate desired velocity
	D3DXVECTOR3 vecDesiredVelocity;
	ZeroMemory(&vecDesiredVelocity, sizeof(D3DXVECTOR3));

	D3DXVec3Subtract(&vecDesiredVelocity, &_vecTarget, &mPos);
	float fDesiredMagnitude = D3DXVec3Length(&vecDesiredVelocity);
	D3DXVec3Normalize(&vecDesiredVelocity, &vecDesiredVelocity);

	//Implement arrival
	if(fDesiredMagnitude < m_fArrivalDist)
	{
		//Set magnitude according to how close we are.
		float fDistRatio = 0.0f;
		if(m_fArrivalDist != 0.0f)
		{
			fDistRatio = fDesiredMagnitude / m_fArrivalDist;
		}

		float fScaledMagnitude = fDistRatio * m_fMaxVelocity;
		D3DXVec3Scale(&vecDesiredVelocity, &vecDesiredVelocity, fScaledMagnitude);
	}
	else
	{
		D3DXVec3Scale(&vecDesiredVelocity, &vecDesiredVelocity, m_fMaxVelocity);
	}


	//Draw desired vector
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_DESIRED] != 0)
		{		
			float fAngle = AngleBetweenVec3(D3DXVECTOR3(0.0f, 1.0f, 0.0f), vecDesiredVelocity);
			if(vecDesiredVelocity.x < 0)
			{
				fAngle = (2 * PI) - fAngle;
			}
	
			m_pComponents[COMPONENT_DESIRED]->SetRoll(-fAngle);
			m_pComponents[COMPONENT_DESIRED]->SetPosition(mPos);
		}
	}

	//Calculate steering force
	D3DXVECTOR3 vecSteering;
	ZeroMemory(&vecSteering, sizeof(D3DXVECTOR3));

	D3DXVec3Subtract(&vecSteering, &vecDesiredVelocity, &mVel);

	//Truncate
	LimitVec3(vecSteering, m_fMaxSteering);
	if(m_fMass != 0.0f)
	{
		D3DXVec3Scale(&vecSteering, &vecSteering, (1/m_fMass));
	}

	//Draw steering vector
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_STEERING] != 0)
		{
			float fAngle = AngleBetweenVec3(D3DXVECTOR3(0.0f, 1.0f, 0.0f), vecSteering);
			if(vecSteering.x < 0)
			{
				fAngle = (2 * PI) - fAngle;
			}
	
			m_pComponents[COMPONENT_STEERING]->SetRoll(-fAngle);
			m_pComponents[COMPONENT_STEERING]->SetPosition(mPos);
		}
	}

	D3DXVec3Add(&mVel, &mVel, &vecSteering);
}

void 
Vehicle::Wander()
{
	//Assign circle center
	D3DXVECTOR3 vecCirclePos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_WANDER] != 0)
		{
			D3DXVec3Normalize(&vecCirclePos, &mVel);
			D3DXVec3Scale(&vecCirclePos, &vecCirclePos, m_fWanderDistance);
		}
	}

	D3DXVECTOR3 vecDisplacement = D3DXVECTOR3(RandF(-1, 1), RandF(-1, 1), 0.0f);
	D3DXVec3Normalize(&vecDisplacement, &vecDisplacement);
	D3DXVec3Scale(&vecCirclePos, &vecCirclePos, m_fWanderRadius);

	//Draw wander component
	D3DXVECTOR3 vecCircleWS = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	D3DXVec3Normalize(&vecCircleWS, &mVel);
	D3DXVec3Scale(&vecCircleWS, &vecCircleWS, m_fWanderDistance);
	D3DXVec3Add(&vecCircleWS, &vecCircleWS, &mPos);
	m_pComponents[COMPONENT_WANDER]->SetPosition(vecCircleWS);

	float fLength = D3DXVec3Length(&vecDisplacement);
	vecDisplacement.x = cosf(m_fWanderAngle) * fLength;
	vecDisplacement.y = sinf(m_fWanderAngle) * fLength;

	//Draw displacement vector
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_DISPLACEMENT] != 0)
		{		
			float fAngle = AngleBetweenVec3(D3DXVECTOR3(0.0f, 1.0f, 0.0f), vecDisplacement);
			if(vecDisplacement.x < 0)
			{
				fAngle = (2 * PI) - fAngle;
			}
	
			m_pComponents[COMPONENT_DISPLACEMENT]->SetRoll(-fAngle);
			m_pComponents[COMPONENT_DISPLACEMENT]->SetPosition(vecCircleWS);
		}
	}


	m_fWanderAngle += (RandF() * m_fWanderChange) - (m_fWanderChange * 0.5f);


	D3DXVECTOR3 vecWanderForce = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	D3DXVec3Add(&vecWanderForce, &vecCirclePos, &vecDisplacement);

	mVel += vecWanderForce;

	//Draw circle component
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_RADIUS] != 0)
		{
			m_pComponents[COMPONENT_RADIUS]->SetPosition(mPos);
		}
	}
}

void
Vehicle::Seperate(const D3DXVECTOR3& _vecTarget)
{
	float fDesiredSeperation = m_fRadius * 2.0f;

	D3DXVECTOR3 vecSum = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	int iVehicleCount = 0;
	for(int i = 0; i < 1; ++i)
	{
		float fDistance = CalculateDistance(&mPos, &_vecTarget);
		if( (fDistance > 0) && (fDistance < fDesiredSeperation) )
		{
			D3DXVECTOR3 vecDifference = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
			D3DXVec3Subtract(&vecDifference, &mPos, &_vecTarget);
			D3DXVec3Normalize(&vecDifference, &vecDifference);

			D3DXVec3Scale(&vecDifference, &vecDifference, (1/fDistance));
			D3DXVec3Add(&vecSum, &vecSum, &vecDifference);
		}

		++iVehicleCount;
	}

	if(iVehicleCount > 0)
	{
		D3DXVec3Scale(&vecSum, &vecSum, (1.0f/iVehicleCount));
		D3DXVec3Normalize(&vecSum, &vecSum);
		D3DXVec3Scale(&vecSum, &vecSum, m_fMaxVelocity);

		D3DXVECTOR3 vecSteering = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		D3DXVec3Subtract(&vecSteering, &vecSum, &mVel);
		LimitVec3(vecSteering, m_fMaxSteering);
		D3DXVec3Add(&mVel, &mVel, &vecSteering);
	}

	//Draw circle component
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_RADIUS] != 0)
		{
			m_pComponents[COMPONENT_RADIUS]->SetPosition(mPos);
		}
	}
}

void 
Vehicle::LeaderFollow(GameObject** _pVehicles, const int _iMaxVehicles)
{
	//Calculate desired velocity
	D3DXVECTOR3 vecDesiredVelocity = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	D3DXVECTOR3 vecTarget = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	if(m_pTarget != 0)
	{
		vecTarget = *(m_pTarget->GetPosition());
	}

	D3DXVec3Subtract(&vecDesiredVelocity, &vecTarget, &mPos);
	float fDesiredMagnitude = D3DXVec3Length(&vecDesiredVelocity);
	D3DXVec3Normalize(&vecDesiredVelocity, &vecDesiredVelocity);

	//Implement arrival
	if(fDesiredMagnitude < m_fArrivalDist)
	{
		//Set magnitude according to how close we are.
		float fDistRatio = 0.0f;
		if(m_fArrivalDist != 0.0f)
		{
			fDistRatio = fDesiredMagnitude / m_fArrivalDist;
		}

		float fScaledMagnitude = fDistRatio * m_fMaxVelocity;
		D3DXVec3Scale(&vecDesiredVelocity, &vecDesiredVelocity, fScaledMagnitude);
	}
	else
	{
		D3DXVec3Scale(&vecDesiredVelocity, &vecDesiredVelocity, m_fMaxVelocity);
	}


	//Draw desired vector
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_DESIRED] != 0)
		{		
			float fAngle = AngleBetweenVec3(D3DXVECTOR3(0.0f, 1.0f, 0.0f), vecDesiredVelocity);
			if(vecDesiredVelocity.x < 0)
			{
				fAngle = (2 * PI) - fAngle;
			}
	
			m_pComponents[COMPONENT_DESIRED]->SetRoll(-fAngle);
			m_pComponents[COMPONENT_DESIRED]->SetPosition(mPos);
		}
	}

	//Calculate steering force
	D3DXVECTOR3 vecSteering;
	ZeroMemory(&vecSteering, sizeof(D3DXVECTOR3));

	D3DXVec3Subtract(&vecSteering, &vecDesiredVelocity, &mVel);

	//Truncate
	LimitVec3(vecSteering, m_fMaxSteering);
	if(m_fMass != 0.0f)
	{
		D3DXVec3Scale(&vecSteering, &vecSteering, (1/m_fMass));
	}

	//Draw steering component
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_STEERING] != 0)
		{		
			float fAngle = AngleBetweenVec3(D3DXVECTOR3(0.0f, 1.0f, 0.0f), vecSteering);
			if(vecSteering.x < 0)
			{
				fAngle = (2 * PI) - fAngle;
			}
	
			m_pComponents[COMPONENT_STEERING]->SetRoll(-fAngle);
			m_pComponents[COMPONENT_STEERING]->SetPosition(mPos);
		}
	}

	D3DXVec3Add(&mVel, &mVel, &vecSteering);





	//Perform seperation
	float fDesiredSeperation = m_fRadius * 2.0f;

	D3DXVECTOR3 vecSum = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	int iVehicleCount = 0;
	if(_pVehicles != 0)
	{
		for(int i = 0; i < _iMaxVehicles; ++i)
		{
			if(_pVehicles[i] != 0)
			{
				if(i != m_iVehicleID)
				{
					D3DXVECTOR3 vecTarget = *(_pVehicles[i]->GetPosition());
					float fDistance = CalculateDistance(&mPos, &vecTarget);
					if( (fDistance > 0) && (fDistance < fDesiredSeperation) )
					{
						D3DXVECTOR3 vecDifference = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
						D3DXVec3Subtract(&vecDifference, &mPos, &vecTarget);
						D3DXVec3Normalize(&vecDifference, &vecDifference);

						D3DXVec3Scale(&vecDifference, &vecDifference, (1/fDistance));
						D3DXVec3Add(&vecSum, &vecSum, &vecDifference);
			
						++iVehicleCount;
					}
				}
			}
		}
	}

	if(iVehicleCount > 0)
	{
		D3DXVec3Scale(&vecSum, &vecSum, (1.0f/1.0f));
		D3DXVec3Normalize(&vecSum, &vecSum);
		D3DXVec3Scale(&vecSum, &vecSum, m_fMaxVelocity);

		D3DXVECTOR3 vecSteering = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		D3DXVec3Subtract(&vecSteering, &vecSum, &mVel);
		LimitVec3(vecSteering, m_fMaxSteering);
		D3DXVec3Add(&mVel, &mVel, &vecSteering);
	}

	//Draw circle component
	if(m_pComponents != 0)
	{
		if(m_pComponents[COMPONENT_RADIUS] != 0)
		{
			m_pComponents[COMPONENT_RADIUS]->SetPosition(mPos);
		}
	}
}

const float 
Vehicle::GetArrivalDist()
{
	return(m_fArrivalDist);
}

void 
Vehicle::SetTarget(Vehicle* _pTarget)
{
	m_pTarget = _pTarget;
}

void
Vehicle::SetVehicleID(const int _iVehicleID)
{
	m_iVehicleID = _iVehicleID;
}

const int
Vehicle::GetVehicleID()
{
	return(m_iVehicleID);
}

void 
Vehicle::SetMaxVelocity(const float _fMaxVelocity)
{
	m_fMaxVelocity = _fMaxVelocity;
}