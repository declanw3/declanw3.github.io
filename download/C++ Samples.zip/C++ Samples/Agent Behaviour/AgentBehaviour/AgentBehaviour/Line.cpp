#include "Line.h"
#include "Vertex.h"

Line::Line()
{

}

Line::~Line()
{

}

const bool
Line::Initialise(ID3D10Device* device, D3DXCOLOR _color, bool _bIndexed)
{
	bool bSuccess = false;

	//Assign device
	md3dDevice = device;

	//Line mesh data
	m_iVertexCount = 2;
	m_iIndexCount = 2;

	//Create Vertex Buffer
	//Populate VertexData
	if(mVB == 0)
	{
		Vertex vertices[2] = {Vertex(D3DXVECTOR3(0.0f, 0.0f, 0.0f), _color), //Line start
								Vertex(D3DXVECTOR3(0.0f, 1.0f, 0.0f), _color)}; //Line end

		D3D10_BUFFER_DESC vbd;
		vbd.Usage = D3D10_USAGE_IMMUTABLE;
		vbd.ByteWidth = sizeof(Vertex) * m_iVertexCount;
		vbd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
		vbd.CPUAccessFlags = 0;
		vbd.MiscFlags = 0;
		D3D10_SUBRESOURCE_DATA vinitData;
		vinitData.pSysMem = vertices;
		HR(md3dDevice->CreateBuffer(&vbd, &vinitData, &mVB));
	}


	//Create the index buffer
	// Populate IndexData
	if(_bIndexed)
	{
		if(mIB == 0)
		{
			DWORD indices[2] = {0, //Line start
								1}; //Line end


			D3D10_BUFFER_DESC ibd;
			ibd.Usage = D3D10_USAGE_IMMUTABLE;
			ibd.ByteWidth = sizeof(DWORD) * m_iIndexCount;
			ibd.BindFlags = D3D10_BIND_INDEX_BUFFER;
			ibd.CPUAccessFlags = 0;
			ibd.MiscFlags = 0;
			D3D10_SUBRESOURCE_DATA iinitData;
			iinitData.pSysMem = indices;
			HR(md3dDevice->CreateBuffer(&ibd, &iinitData, &mIB));
		}
	}

	return(bSuccess);
}

void 
Line::Draw(ID3D10Device* device)
{
	md3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_LINESTRIP);

	Shape::Draw(device);
}