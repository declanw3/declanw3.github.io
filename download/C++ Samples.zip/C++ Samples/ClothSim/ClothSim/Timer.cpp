//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   SceneApp.cpp
//  Description :   SceneApp implementation file
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

// Library Includes
#include <windows.h>

// Local Includes
// This Include
#include "Timer.h"

// Static Variables
// Static Function Prototypes
// Implementation

Timer::Timer()
:mSecondsPerCount(0.0)
,mDeltaTime(-1.0)
,mBaseTime(0)
,mPausedTime(0)
,mPreviousTime(0)
,mCurrentTime(0)
,mStopped(false)
{
	__int64 countsPerSec;
	QueryPerformanceFrequency((LARGE_INTEGER*)&countsPerSec);
	mSecondsPerCount = 1.0 / (double)countsPerSec;
}

// Returns the total time elapsed since reset() was called, NOT counting any
// time when the clock is stopped.
float 
Timer::getGameTime()const
{
	// If we are stopped, do not count the time that has passed since we stopped.
	//
	// ----*---------------*------------------------------*------> time
	//  mBaseTime       mStopTime                      mCurrentTime

	if( mStopped )
	{
		return (float)((mStopTime - mBaseTime)*mSecondsPerCount);
	}

	// The distance mCurrentTime - mBaseTime includes paused time,
	// which we do not want to count.  To correct this, we can subtract 
	// the paused time from mCurrentTime:  
	//
	//  (mCurrentTime - mPausedTime) - mBaseTime 
	//
	//                     |<-------d------->|
	// ----*---------------*-----------------*------------*------> time
	//  mBaseTime       mStopTime        startTime     mCurrentTime
	
	else
	{
		return (float)(((mCurrentTime-mPausedTime)-mBaseTime)*mSecondsPerCount);
	}
}

float 
Timer::getDeltaTime()const
{
	return (float)mDeltaTime;
}

void 
Timer::reset()
{
	__int64 currTime;
	QueryPerformanceCounter((LARGE_INTEGER*)&currTime);

	mBaseTime = currTime;
	mPreviousTime = currTime;
	mStopTime = 0;
	mStopped  = false;
}

void 
Timer::start()
{
	__int64 startTime;
	QueryPerformanceCounter((LARGE_INTEGER*)&startTime);


	// Accumulate the time elapsed between stop and start pairs.
	//
	//                     |<-------d------->|
	// ----*---------------*-----------------*------------> time
	//  mBaseTime       mStopTime        startTime     

	if( mStopped )
	{
		mPausedTime += (startTime - mStopTime);	

		mPreviousTime = startTime;
		mStopTime = 0;
		mStopped  = false;
	}
}

void
Timer::stop()
{
	if( !mStopped )
	{
		__int64 currTime;
		QueryPerformanceCounter((LARGE_INTEGER*)&currTime);

		mStopTime = currTime;
		mStopped  = true;
	}
}

void 
Timer::tick()
{
	if( mStopped )
	{
		mDeltaTime = 0.0;
		return;
	}

	__int64 currTime;
	QueryPerformanceCounter((LARGE_INTEGER*)&currTime);
	mCurrentTime = currTime;

	// Time difference between this frame and the previous.
	mDeltaTime = (mCurrentTime - mPreviousTime)*mSecondsPerCount;

	// Prepare for next frame.
	mPreviousTime = mCurrentTime;

	// Force nonnegative.  The DXSDK's CDXUTTimer mentions that if the 
	// processor goes into a power save mode or we get shuffled to another
	// processor, then mDeltaTime can be negative.
	if(mDeltaTime < 0.0)
	{
		mDeltaTime = 0.0;
	}
}