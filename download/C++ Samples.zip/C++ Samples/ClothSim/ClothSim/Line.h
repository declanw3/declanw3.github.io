//
//  Diploma of Interactive Gaming
//  Media Design School
//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Line.h
//  Description :   Header for the Line class
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

#ifndef __LINE_H__
#define __LINE_H__

// Library Includes
// Local Includes
#include "GameObject.h"

// Types
// Constants
// Prototypes

class Line : public GameObject
{
public:
	Line();
	~Line();

	virtual bool Initialise(ID3D10Device* device);
	void DrawLine(D3DXVECTOR3* _vec3StartPoint, D3DXVECTOR3* _vecEndPoint);

protected:
private:

public:
protected:
private:
	int mNumVertices;

	ID3D10Device* md3dDevice;//Device
	ID3D10Buffer* mVB; // Vertex buffer
};

#endif // __LINE_H__