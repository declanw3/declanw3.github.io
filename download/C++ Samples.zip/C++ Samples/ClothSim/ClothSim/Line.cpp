//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Line.cpp
//  Description :   Line implementation file
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

// Library Includes
// Local Includes
#include "Vertex.h"

// This Include
#include "Line.h"

// Static Variables
// Static Function Prototypes
// Implementation

Line::Line()
:mNumVertices(0)
,md3dDevice(NULL)
,mVB(NULL)
{

}

Line::~Line()
{
	ReleaseCOM(mVB);
}

bool
Line::Initialise(ID3D10Device* device)
{
	md3dDevice = device;
	mNumVertices = 2;

	// Create vertex buffer
	Vertex vertices[] =
	{
		{D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 1.0f, 0.0f)},
		{D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 1.0f, 0.0f)}
	};

	D3D10_BUFFER_DESC vbd;
	vbd.Usage = D3D10_USAGE_DYNAMIC;
	vbd.ByteWidth = sizeof(Vertex) * mNumVertices;
	vbd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
	vbd.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
	vbd.MiscFlags = 0;
	D3D10_SUBRESOURCE_DATA vinitData;
	vinitData.pSysMem = vertices;
	HR(md3dDevice->CreateBuffer(&vbd, &vinitData, &mVB));

	return(false);
}

/**
*
* This function draws a line using two positions.
* (Task ID: -)
*
* @author Declan Wong
* @param _vec3StartPoint. This value is the start point.
* @param _vecEndPoint. This value is the start point.
* @return void.
*
*/
void
Line::DrawLine(D3DXVECTOR3* _vec3StartPoint, D3DXVECTOR3* _vecEndPoint)
{
	if(!mVB)
	{

	}
	else
	{
		// Initialize the vertex buffer pointer to null first.
		void* verticesPtr = 0;

		HRESULT result = -1;
		result = mVB->Map(D3D10_MAP_WRITE_DISCARD, 0, (void**)&verticesPtr);
		if(FAILED(result))
		{
			return;
		}

		// Create vertex buffer
		Vertex vertices[] =
		{
			{*(_vec3StartPoint), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 1.0f, 0.0f)},
			{*(_vecEndPoint), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 1.0f, 0.0f)}
		};

		// Copy the data into the vertex buffer.
		memcpy(verticesPtr, (void*)vertices, (sizeof(Vertex) * mNumVertices));

		// Unlock the vertex buffer.
		mVB->Unmap();

		UINT stride = sizeof(Vertex);
		UINT offset = 0;
		md3dDevice->IASetVertexBuffers(0, 1, &mVB, &stride, &offset);
		md3dDevice->Draw(mNumVertices, 0);
	}
}



