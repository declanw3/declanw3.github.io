//
//  Diploma of Interactive Gaming
//  Media Design School
//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Vertex.h
//  Description :   Header for the Vertex struct
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

// Library Includes
// Local Includes
#include "Utility.h"

// Types
// Constants
// Prototypes

#ifndef VERTEX_H
#define VERTEX_H

struct Vertex
{
	D3DXVECTOR3 pos;
	D3DXVECTOR3 normal;
	D3DXVECTOR4 diffuse;
	D3DXVECTOR4 specular;
};

#endif // VERTEX_H