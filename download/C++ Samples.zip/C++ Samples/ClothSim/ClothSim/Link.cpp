//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Link.cpp
//  Description :   Link implementation file
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

// Library Includes
// Local Includes
#include "Point.h"

// This Include
#include "Link.h"

// Static Variables
// Static Function Prototypes
// Implementation

Link::Link()
:m_pStartPoint(0)
,m_pEndPoint(0)
,m_fStiffness(0.8f)
,m_fRestingDist(1.0f)
,m_bTorn(false)
{

}

Link::~Link()
{

}

/**
*
* This function updates the Link per frame.
* (Task ID: -)
*
* @author Declan Wong
* @param dt. This the delta time scalar.
* @return void.
*
*/
void
Link::Update(float dt)
{
	ConstraintSolver(dt);
}

/**
*
* This function resolves Point constraints.
* (Task ID: -)
*
* @author Declan Wong
* @param dt. This the delta time scalar.
* @return void.
*
*/
void 
Link::ConstraintSolver(float dt)
{
	//Avoid processing if torn
	if( !m_bTorn )
	{
		D3DXVECTOR3 vec3StartPointPos = *(m_pStartPoint->GetCurrentPos());
		D3DXVECTOR3 vec3EndPointPos = *(m_pEndPoint->GetCurrentPos());
	
		D3DXVECTOR3 vec3Delta = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		D3DXVec3Subtract(&vec3Delta, &vec3StartPointPos, &vec3EndPointPos);

		float fDeltaLength = D3DXVec3Length(&vec3Delta);
		float fDifference = (m_fRestingDist - fDeltaLength) / fDeltaLength;

		//Implement tearing threshold
		if(fDeltaLength > 22.5f)
		{
			m_bTorn = true;
		}

		float fInverseMass1 = 1 / m_pStartPoint->GetMass();
		float fInverseMass2 = 1 / m_pEndPoint->GetMass();

		vec3StartPointPos += vec3Delta * (fInverseMass1 / (fInverseMass1 + fInverseMass2) * m_fStiffness * fDifference);
		vec3EndPointPos -= vec3Delta * (fInverseMass2 / (fInverseMass1 + fInverseMass2) * m_fStiffness * fDifference);

		//Do not assign new position if fixed
		if( !m_pStartPoint->GetFixed() )
		{
			m_pStartPoint->SetCurrentPos(vec3StartPointPos);
		}
		if( !m_pEndPoint->GetFixed() )
		{
			m_pEndPoint->SetCurrentPos(vec3EndPointPos);
		}
	}
}

Point* 
Link::GetStartPoint()
{
	return(m_pStartPoint);
}

void 
Link::SetStartPoint(Point* _pStartPoint)
{
	m_pStartPoint = _pStartPoint;
}

Point* 
Link::GetEndPoint()
{
	return(m_pEndPoint);
}

void 
Link::SetEndPoint(Point* _pEndPoint)
{
	m_pEndPoint = _pEndPoint;
}


const bool 
Link::GetTorn()
{
	return(m_bTorn);
}

void 
Link::SetTorn(const bool _bTorn)
{
	m_bTorn = _bTorn;
}

D3DXVECTOR3 
Link::GetLinkCenter()
{
	D3DXVECTOR3 vec3Center = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	vec3Center = (*(m_pStartPoint->GetCurrentPos()) + *(m_pEndPoint->GetCurrentPos())) / 2;

	return(vec3Center);
}