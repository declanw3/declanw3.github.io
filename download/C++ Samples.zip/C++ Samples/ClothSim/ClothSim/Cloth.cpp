//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Cloth.cpp
//  Description :   Cloth implementation file
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

// Library Includes
// Local Includes
#include "Utility.h"
#include "Point.h"
#include "Link.h"
#include "Line.h"

// This Include
#include "Cloth.h"

// Static Variables
// Static Function Prototypes
// Implementation

Cloth::Cloth()
:m_iWidth(0)
,m_iHeight(0)
,m_iTotalPoints(0)
,m_iTotalLinks(0)
,m_fFloorY(-50.0f)
,m_pPoints(NULL)
,m_pLinks(NULL)
,m_pLine(NULL)
,m_bWind(true)
{

}

Cloth::~Cloth()
{
	Deinitialise();
}

/**
*
* This function initialises the Cloth.
* (Task ID: -)
*
* @author Declan Wong
* @param device. This value is passed in to initialise the vertex buffer.
* @param _kiWidthInPoints. This value is the width in points of the Cloth.
* @param _kiHeightInPoints. This value is the height in points of the Cloth.
* @return Returns true if Initialise() is successful.
*
*/
bool
Cloth::Initialise(ID3D10Device* device, const int _kiWidthInPoints, const int _kiHeightInPoints)
{
	//Equate total links/points
	m_iTotalPoints = _kiWidthInPoints * _kiHeightInPoints;
	m_iTotalLinks = ((_kiWidthInPoints - 1) * _kiHeightInPoints) +
					((_kiHeightInPoints - 1) * _kiWidthInPoints);
	
	//Initialise Points
	if(m_pPoints == 0)
	{
		m_pPoints = new Point*[m_iTotalPoints];

		int iCurrentPoint = 0;
		for(int iColumn = 0; iColumn < _kiHeightInPoints; ++iColumn)
		{
			for(int iRow = 0; iRow < _kiWidthInPoints; ++iRow)
			{
				m_pPoints[iCurrentPoint] = new Point();
				m_pPoints[iCurrentPoint]->SetCurrentPos( D3DXVECTOR3(static_cast<float>(iRow), 
																	-static_cast<float>(iColumn), 
																	RandF(-2.0f, 2.0f)) );
				m_pPoints[iCurrentPoint]->SetMass(1.0f);

				++iCurrentPoint;
			}
		}
	}
	//Set fixed points
	m_pPoints[0]->SetFixed(true);
	m_pPoints[19]->SetFixed(true);
	m_pPoints[39]->SetFixed(true);

	//Initialise Links
	int iCurrentPoint = 0;
	int iCurrentLink = 0;
	if(m_pLinks == 0)
	{
		m_pLinks = new Link*[m_iTotalLinks];

		if(m_pPoints != 0)
		{
			for(int iColumn = 0; iColumn < _kiHeightInPoints; ++iColumn)
			{
				for(int iRow = 0; iRow < _kiWidthInPoints; ++iRow)
				{
					//Create horizontal and vertical links
					if(iRow != 0)
					{
						m_pLinks[iCurrentLink] = new Link();
						m_pLinks[iCurrentLink]->SetStartPoint( m_pPoints[iCurrentPoint] );
						m_pLinks[iCurrentLink]->SetEndPoint( m_pPoints[iCurrentPoint - 1] );
						++iCurrentLink;
					}
					if(iColumn != 0)
					{
						m_pLinks[iCurrentLink] = new Link();
						m_pLinks[iCurrentLink]->SetStartPoint( m_pPoints[iCurrentPoint] );
						m_pLinks[iCurrentLink]->SetEndPoint( m_pPoints[iCurrentPoint - (_kiWidthInPoints)] );
						++iCurrentLink;
					}

					++iCurrentPoint;
				}
			}
		}
	}

	//Initialise drawing line
	if(m_pLine == 0)
	{
		m_pLine = new Line();
		m_pLine->Initialise(device);
	}

	return(false);
}

/**
*
* This function cleans up memory allocations.
* (Task ID: -)
*
* @author Declan Wong
* @return void.
*
*/
void
Cloth::Deinitialise()
{
	//Deinitialise Point container
	if(m_pPoints != 0)
	{
		for(int i = 0; i < m_iTotalPoints; ++i)
		{
			if(m_pPoints[i] != 0)
			{
				delete m_pPoints[i];
				m_pPoints[i] = 0;
			}
		}

		delete[] m_pPoints;
		m_pPoints = 0;
	}

	//Deinitialise Link container
	if(m_pLinks != 0)
	{
		for(int i = 0; i < m_iTotalLinks; ++i)
		{
			if(m_pLinks[i] != 0)
			{
				delete m_pLinks[i];
				m_pLinks[i] = 0;
			}
		}

		delete[] m_pLinks;
		m_pLinks = 0;
	}

	//Deinitialise Line
	if(m_pLine != 0)
	{
		delete m_pLine;
		m_pLine = 0;
	}
}

/**
*
* This function updates the Cloth per frame.
* (Task ID: -)
*
* @author Declan Wong
* @param dt. This the delta time scalar.
* @return void.
*
*/
void 
Cloth::Update(float dt)
{
	//Update each Point
	if(m_pPoints != 0)
	{
		for(int i = 0; i < m_iTotalPoints; ++i)
		{
			if(m_pPoints[i] != 0)
			{ 
				//Apply wind
				if(m_bWind)
				{
					static float fWave = 0.0f;
					float fWindZ = 0.0f;
					fWave += dt * 0.0005f;
					fWindZ = sinf(fWave);


					//float fX = RandF(-1000.0f, 1000.0f);
					//float fY = RandF(-1000.0f, 1000.0f);
					//float fZ = RandF(-1000.0f, 1000.0f);
					int iRandomPoint = ((rand() % m_iTotalPoints) / 2) + (m_iTotalPoints / 2);

					m_pPoints[iRandomPoint]->ApplyForce(D3DXVECTOR3(fWindZ * 100.0f, 0.0f, fWindZ * 1000.0f));
					m_pPoints[iRandomPoint]->Update(dt);
				}

				//Apply gravity
				m_pPoints[i]->ApplyForce(D3DXVECTOR3(0.0f, -500.0f, 0.0f));
				m_pPoints[i]->Update(dt);
			}
		}
	}

	//Update each Link
	if(m_pLinks != 0)
	{
		for(int i = 0; i < m_iTotalLinks; ++i)
		{
			if(m_pLinks[i] != 0)
			{
				m_pLinks[i]->Update(dt);
			}
		}
	}

	ProcessFloor();

	GameObject::Update(dt);
}

/**
*
* This function draws the Cloth per frame.
* (Task ID: -)
*
* @author Declan Wong
* @param device. This value is the D3DDevice used to render the buffer.
* @return void.
*
*/
void
Cloth::Draw(ID3D10Device* device)
{
	if(m_pLine != 0)
	{
		if(m_pLinks != 0)
		{
			//Draw each Link
			for(int i = 0; i < m_iTotalLinks; ++i)
			{
				if(m_pLinks[i] != 0)
				{
					if( !m_pLinks[i]->GetTorn() )
					{
						m_pLine->DrawLine(m_pLinks[i]->GetStartPoint()->GetCurrentPos(),
										m_pLinks[i]->GetEndPoint()->GetCurrentPos());
					}
				}
			}

			//Draw floor
			if(m_pLine != 0)
			{
				m_pLine->DrawLine(&(D3DXVECTOR3(-100.0f, m_fFloorY, 100.0f)), 
									&(D3DXVECTOR3(100.0f, m_fFloorY, 100.0f))); 

				m_pLine->DrawLine(&(D3DXVECTOR3(-100.0f, m_fFloorY, -100.0f)), 
									&(D3DXVECTOR3(100.0f, m_fFloorY, -100.0f))); 

				m_pLine->DrawLine(&(D3DXVECTOR3(100.0f, m_fFloorY, -100.0f)), 
									&(D3DXVECTOR3(100.0f, m_fFloorY, 100.0f))); 

				m_pLine->DrawLine(&(D3DXVECTOR3(-100.0f, m_fFloorY, 100.0f)), 
									&(D3DXVECTOR3(-100.0f, m_fFloorY, -100.0f))); 
			}

			//Draw rail
			if(m_pLine != 0)
			{
				//m_pLine->DrawLine(m_pPoints[0]->GetCurrentPos(), 
				//				m_pPoints[39]->GetCurrentPos()); 
			}
		}
	}
}

/**
*
* This function releases all fixed Points.
* (Task ID: -)
*
* @author Declan Wong
* @return void.
*
*/
void
Cloth::ReleaseFixed()
{
	if(m_pPoints != 0)
	{
		for(int i = 0; i < m_iTotalPoints; ++i)
		{
			if(m_pPoints[i] != 0)
			{
				m_pPoints[i]->SetFixed(false);
			}
		}
	}
}

/**
*
* This function updates Point positions based on floor.
* (Task ID: -)
*
* @author Declan Wong
* @return void.
*
*/
void 
Cloth::ProcessFloor()
{
	if(m_pPoints != 0)
	{
		for(int i = 0; i < m_iTotalPoints; ++i)
		{
			if(m_pPoints[i] != 0)
			{
				if(m_pPoints[i]->GetCurrentPos()->y < m_fFloorY)
				{
					m_pPoints[i]->GetCurrentPos()->y = m_fFloorY;
					m_pPoints[i]->SetFixed(true);
				}
			}
		}
	}
}


const int 
Cloth::GetTotalPoints()
{
	return(m_iTotalPoints);
}
	
Point* 
Cloth::GetPoint(const int _iIndex)
{
	Point* _pPoint = 0;
	
	if(m_pPoints[_iIndex] != 0)
	{
		_pPoint = m_pPoints[_iIndex];
	}

	return(_pPoint);
}

const int 
Cloth::GetTotalLinks()
{
	return(m_iTotalLinks);
}
	
Link* 
Cloth::GetLink(const int _iIndex)
{
	Link* _pLink = 0;
	
	if(m_pLinks[_iIndex] != 0)
	{
		_pLink = m_pLinks[_iIndex];
	}

	return(_pLink);
}

void
Cloth::ToggleWind()
{
	m_bWind = !m_bWind;
}