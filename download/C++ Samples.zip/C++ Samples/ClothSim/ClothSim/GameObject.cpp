//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Cloth.cpp
//  Description :   Cloth implementation file
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

// Library Includes
// Local Includes
// This Include
#include "GameObject.h"

// Static Variables
// Static Function Prototypes
// Implementation

GameObject::GameObject()
: mfYaw(0.0f)
, mfPitch(0.0f)
, mfRoll(0.0f)
, m_fScale(0.0f)
,m_bActive(true)
{
	D3DXMatrixIdentity(&mWorldMat);
	ZeroMemory(&mPos, sizeof(D3DXVECTOR3));
	ZeroMemory(&mDir, sizeof(D3DXVECTOR3));

	m_fScale = 1.0f;

	m_strID = "NULL";
}

GameObject::~GameObject()
{

}

bool 
GameObject::Initialise(ID3D10Device* device, float scale)
{

	return(false);
}

/**
*
* This function updates the GameObject per frame.
* (Task ID: -)
*
* @author Declan Wong
* @param dt. This the delta time scalar.
* @return void.
*
*/
void
GameObject::Update(float dt)
{
	D3DXMATRIX matRotation;
	D3DXMatrixRotationZ(&matRotation, mfRoll);

	D3DXMATRIX matTranslation;
	D3DXMatrixTranslation(&matTranslation, mPos.x, mPos.y, mPos.z);

	D3DXMatrixMultiply(&mWorldMat, &matRotation, &matTranslation);

	D3DXMATRIX matScaling;
	D3DXMatrixScaling(&matScaling, m_fScale, m_fScale, m_fScale);
	D3DXMatrixMultiply(&mWorldMat, &matScaling, &mWorldMat);
}

/**
*
* This function draws the GameObject per frame.
* (Task ID: -)
*
* @author Declan Wong
* @param device. This value is the D3DDevice used to render the buffer.
* @return void.
*
*/
void 
GameObject::Draw(ID3D10Device* device)
{

}

void
GameObject::SetScale(const float _fScale)
{
	m_fScale = _fScale;
}

void 
GameObject::SetRoll(const float _fRoll)
{
	mfRoll = _fRoll;
}

const D3DXMATRIX*
GameObject::GetWorldMat()
{
	return(&mWorldMat);
}

const D3DXVECTOR3*
GameObject::GetPosition()
{
	return(&mPos);
}

void 
GameObject::SetPosition(const D3DXVECTOR3& _vecPos)
{
	mPos = _vecPos;
}

const char*
GameObject::GetID()
{
	return(m_strID.c_str());
}

const bool
GameObject::SetID(const char* _kcID)
{
	m_strID = _kcID;

	return(false);
}

const bool
GameObject::GetActive()
{
	return(m_bActive);
}

void 
GameObject::SetActive(const bool _bActive)
{
	m_bActive = _bActive;
}