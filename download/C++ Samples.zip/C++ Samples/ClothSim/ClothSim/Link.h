//
//  Diploma of Interactive Gaming
//  Media Design School
//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Link.h
//  Description :   Header for the Link class
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

#ifndef __LINK_H__
#define __LINK_H__

// Library Includes
// Local Includes
#include "Utility.h"

// Types
// Constants
// Prototypes

class Point;
class Link
{
	// Member Variables
public:
protected:
private:
	Point* m_pStartPoint;
	Point* m_pEndPoint;

	float m_fStiffness;
	float m_fRestingDist;
	bool m_bTorn;

	// Member Functions
public:
	Link();
	~Link();

	void Update(float dt);
	void ConstraintSolver(float dt);

	Point* GetStartPoint();
	void SetStartPoint(Point* _pStartPoint);

	Point* GetEndPoint();
	void SetEndPoint(Point* _pEndPoint);

	const bool GetTorn();
	void SetTorn(const bool _bTorn);

	D3DXVECTOR3 GetLinkCenter();

protected:
private:
};

#endif //__LINK_H__