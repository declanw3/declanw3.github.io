//
//  Diploma of Interactive Gaming
//  Media Design School
//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Camera.h
//  Description :   Header for the Camera class
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

#ifndef Camera_H
#define Camera_H

// Library Includes
// Local Includes
#include "Utility.h"

// Types
// Constants
// Prototypes

class Camera
{
	// Member Variables
public:
protected:
private:
	D3DXVECTOR3 m_vecPos;
	D3DXVECTOR3 m_vecUp;
	D3DXVECTOR3 m_vecRight;
	D3DXVECTOR3 m_vecDir;  

	D3DXMATRIX m_matView;
	D3DXMATRIX m_matProj;

	D3DXMATRIX m_matPreviousVP;

	// Camera Functionality
	float m_fPitch;
	float m_fYaw;
	float m_fRoll;

	//Test
	float m_fMoveAccel;
	float m_fMoveVel;
	float m_fStrafeAccel;
	float m_fStrafeVel;
	float m_fFlyAccel;
	float m_fFlyVel;

	float m_fYawAccel;
	float m_fYawVel;
	float m_fPitchAccel;
	float m_fPitchVel;
	float m_fRollAccel;
	float m_fRollVel;


	// Member Functions
public:
	Camera();
	~Camera();

	void Update(float dt);
	void CalculateProjMatrix(float _fClientWidth, float _fClientHeight);
	void ResetCamera();
	void FreezeMovement();

	void Move(float _fDistance);
	void Strafe(float _fDistance);
	void Fly(float _fDistance);

	void Yaw(float _fAngle);
	void Pitch(float _fAngle);
	void Roll(float _fAngle);

	//Test
	void Move();
	void Strafe();
	void Fly();

	void Yaw();
	void Pitch();
	void Roll();

	D3DXMATRIX* GetViewMatrix();
	D3DXMATRIX* GetProjMatrix();

	D3DXVECTOR3* GetLookAt();
	D3DXVECTOR3* GetPos();

	void SetPreviousVP();
	D3DXMATRIX* GetPreviousVP();

protected:
private:
};

#endif Camera_H