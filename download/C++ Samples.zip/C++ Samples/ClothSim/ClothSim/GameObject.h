//
//  Diploma of Interactive Gaming
//  Media Design School
//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   GameObject.h
//  Description :   Header for the GameObject class
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

#ifndef _GAMEOBJECT_H_
#define _GAMEOBJECT_H_

// Library Includes
#include <string>

// Local Includes
#include "Utility.h"

// Types
// Constants
// Prototypes

class GameObject
{
public:
	GameObject();
	virtual ~GameObject();

	virtual bool Initialise(ID3D10Device* device, float scale);
	virtual void Update(float dt);
	virtual void Draw(ID3D10Device* device);

	virtual const D3DXMATRIX* GetWorldMat();
	virtual void SetScale(const float _fScale);
	virtual void SetRoll(const float _fRoll);

	virtual const D3DXVECTOR3* GetPosition();
	virtual void SetPosition(const D3DXVECTOR3& _vecPos);

	virtual const char* GetID();
	virtual const bool SetID(const char* _kcID);

	virtual const bool GetActive();
	virtual void SetActive(const bool _bActive);

protected:
private:

public:
protected:
	D3DXMATRIX mWorldMat;

	D3DXVECTOR3 mPos;
	D3DXVECTOR3 mDir;

	float mfYaw;
	float mfPitch;
	float mfRoll;

	float m_fScale;

	//Shape* m_pShape;

	//int m_iMaxComponents;
	//GameObject** m_pComponents;
	std::string m_strID;

	bool m_bActive;

private:
};

#endif //_GAMEOBJECT_H_