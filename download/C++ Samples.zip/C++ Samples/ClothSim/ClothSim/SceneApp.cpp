//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   SceneApp.cpp
//  Description :   SceneApp implementation file
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

// Library Includes
// Local Includes
// This Include
#include "WindowApp.h"
#include "Camera.h"
#include "GameObject.h"
#include "Line.h"
#include "Cloth.h"
#include "Point.h"
#include "Link.h"
#include "Light.h"

// Static Variables
// Static Function Prototypes
// Implementation

class SceneApp : public WindowApp
{
public:
	SceneApp(HINSTANCE hInstance);
	~SceneApp();

	void initApp();
	void onResize();
	void updateScene(float dt);
	void drawScene(); 

	void DeinitialiseGameObjects();
	void Draw(GameObject* _pGameObject, const int _iPassCount, D3DXMATRIX* CameraViewMat, D3DXMATRIX* CameraProjMat);
	void ProjectMouse(D3DXVECTOR3& rayOrigin, D3DXVECTOR3& rayDirection);
	void IntersectCloth(D3DXVECTOR3 rayOrigin, D3DXVECTOR3 rayDirection, float fHitRadius);
	void GrabCloth(D3DXVECTOR3 rayOrigin, D3DXVECTOR3 rayDirection, float fHitRadius);
	void GetCollisionPoint(D3DXVECTOR3 vec3Pos, D3DXVECTOR3 rayOrigin, D3DXVECTOR3 rayDirection, D3DXVECTOR3& rayCollision);

	LRESULT msgProc(UINT msg, WPARAM wParam, LPARAM lParam);

private:
	void buildFX();
	void buildVertexLayouts();
 
private:
	Cloth* mCloth;
	int miClothWidth;
	int miClothHeight;

	Camera mCamera;
	Light mLights[3];

	ID3D10Effect* mFX;
	ID3D10EffectTechnique* mTech;
	ID3D10InputLayout* mVertexLayout;
	ID3D10EffectMatrixVariable* mfxWVPVar;
	ID3D10EffectScalarVariable* mfxDeltaVar;

	ID3D10EffectMatrixVariable* mfxWorldVar;
	ID3D10EffectVariable* mfxLightVar;
	ID3D10EffectScalarVariable* mfxLightTypeVar;
	ID3D10EffectVariable* mfxEyePosWVar;

	D3DXMATRIX mWVP;

	//Mouse position
	float mfLocalMouseX;
	float mfLocalMouseY;
	float mfWorldMouseX;
	float mfWorldMouseY;

	//Cube rotation
	bool	  mbUpArrow;
	bool	  mbDownArrow;
	bool	  mbLeftArrow;
	bool	  mbRightArrow;

	//Camera functionality
	bool	  mbMoveForward;
	bool	  mbMoveBack;
	bool	  mbMoveLeft;
	bool	  mbMoveRight;
	bool	  mbLookUp;
	bool	  mbLookDown;
	bool	  mbLookLeft;
	bool	  mbLookRight;
	bool	  mbAscend;
	bool	  mbDescend;
	bool	  mbRollRight;
	bool	  mbRollLeft;

	bool	  mbLMBDown;
	bool	  mbRMBDown;
	
	Point*	  mpGrabbedPoint;
	bool	  mbPointGrabbed;

	int		  miActiveLight;
};

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE prevInstance,
				   PSTR cmdLine, int showCmd)
{
	// Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif


	SceneApp theApp(hInstance);
	
	theApp.initApp();

 	return theApp.run();
}

SceneApp::SceneApp(HINSTANCE hInstance)
:WindowApp(hInstance)
,mFX(0)
,mTech(0)
,mVertexLayout(0)
,mfxWVPVar(0) 
,mfLocalMouseX(0.0f)
,mfLocalMouseY(0.0f)
,mfWorldMouseX(0.0f)
,mfWorldMouseY(0.0f)
,miActiveLight(0)
{
	D3DXMatrixIdentity(&mWVP); 

	mfxDeltaVar = 0;

	//Booleans controlling arrow key presses
	mbUpArrow		= false;
	mbDownArrow		= false;
	mbLeftArrow		= false;
	mbRightArrow	= false;

	mbMoveForward	= false;
	mbMoveBack		= false;
	mbMoveLeft		= false;
	mbMoveRight		= false;
	mbLookUp		= false;
	mbLookDown		= false;
	mbLookLeft		= false;
	mbLookRight		= false;
	mbAscend		= false;
	mbDescend		= false;
	mbRollRight		= false;
	mbRollLeft		= false;

	mbLMBDown		= false;
	mbRMBDown		= false;

	mCloth = NULL;
	miClothWidth = 40;
	miClothHeight = 20;

	mpGrabbedPoint = NULL;
	mbPointGrabbed = false;
}

SceneApp::~SceneApp()
{
	if( md3dDevice )
		md3dDevice->ClearState();

	ReleaseCOM(mFX);
	ReleaseCOM(mVertexLayout);

	DeinitialiseGameObjects();
}

void 
SceneApp::initApp()
{
	WindowApp::initApp();

	mCloth = new Cloth();
	mCloth->Initialise(md3dDevice, miClothWidth, miClothHeight);

	//Initialising lights
	mLights[0].ambient.r = 0.9f;
	mLights[0].diffuse.r = 0.9f;
	mLights[0].specular.r = 1.0f;
	mLights[0].pos.y = 25.0f;
	mLights[0].dir.y = -1.0f;
	mLights[0].spotPow = 100.0f;
	mLights[0].range = 200.0f;

	mLights[1].ambient.g = 0.5f;
	mLights[1].diffuse.g = 0.5f;
	mLights[1].specular.g = 0.5f;
	mLights[1].pos.y = 50.0f;
	mLights[1].dir.y = -1.0f;
	mLights[1].spotPow = 1.0f;
	mLights[1].range = 50.0f;

	mLights[2].ambient.b = 0.5f;
	mLights[2].diffuse.b = 0.5f;
	mLights[2].specular.b = 0.5f;
	mLights[2].pos.y = 25.0f;
	mLights[2].dir.y = -1.0f;
	mLights[2].spotPow = 1.0f;
	mLights[2].range = 30.0f;

	buildFX();
	buildVertexLayouts();
}

void
SceneApp::onResize()
{
	WindowApp::onResize();

	mCamera.CalculateProjMatrix(static_cast<float>(mClientWidth), 
								 static_cast<float>(mClientHeight));
}

/**
*
* This function updates the Scene per frame.
* (Task ID: -)
*
* @author Declan Wong
* @param dt. This the delta time scalar.
* @return void.
*
*/
void 
SceneApp::updateScene(float dt)
{
	WindowApp::updateScene(dt);

	//Camera input
	if(mbMoveForward)	mCamera.Move(0.110f * dt);
	if(mbMoveBack)		mCamera.Move(-0.110f * dt);
	if(mbMoveLeft)		mCamera.Strafe(-0.110f * dt);
	if(mbMoveRight)		mCamera.Strafe(0.110f * dt);
	if(mbAscend)		mCamera.Fly(0.110f * dt);
	if(mbDescend)		mCamera.Fly(-0.110f * dt);

	if(mbLookLeft)		mCamera.Yaw(-0.003f * dt);
	if(mbLookRight)		mCamera.Yaw(0.003f * dt);
	if(mbLookUp)		mCamera.Pitch(-0.002f * dt);
	if(mbLookDown)		mCamera.Pitch(0.002f * dt);
	if(mbRollRight)		mCamera.Roll(-0.002f * dt);
	if(mbRollLeft)		mCamera.Roll(0.002f * dt);

	//Camera
	mCamera.Update(dt);

	//Update cloth
	if(mCloth != 0)
	{
		mCloth->Update(dt);
	}

	mfxLightVar->SetRawValue(&(mLights[miActiveLight]), 0, sizeof(Light));
	mfxLightTypeVar->SetInt(miActiveLight);
	mfxEyePosWVar->SetRawValue(mCamera.GetPos(), 0, sizeof(D3DXVECTOR3));

	if(mbRMBDown)
	{
		D3DXVECTOR3 rayOrigin, rayDirection;
		ProjectMouse(rayOrigin, rayDirection);
		
		// Now perform the ray-sphere intersection test.
		IntersectCloth(rayOrigin, rayDirection, 0.5f);
	}

	if(mbLMBDown && !mbPointGrabbed)
	{
		D3DXVECTOR3 rayOrigin, rayDirection;
		ProjectMouse(rayOrigin, rayDirection);
		
		GrabCloth(rayOrigin, rayDirection, 1.0f);
	}

	if(mbLMBDown && mbPointGrabbed)
	{
		if(mpGrabbedPoint != 0)
		{
			D3DXVECTOR3 vec3CurrentPos = *(mpGrabbedPoint->GetCurrentPos());
			D3DXVECTOR3 vec3NewPos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

			D3DXVECTOR3 rayOrigin, rayDirection;
			ProjectMouse(rayOrigin, rayDirection);
			GetCollisionPoint(vec3CurrentPos, rayOrigin, rayDirection, vec3NewPos);

			mpGrabbedPoint->SetCurrentPos(vec3NewPos);
		}
	}
}

/**
*
* This function draws the Scene per frame.
* (Task ID: -)
*
* @author Declan Wong
* @return void.
*
*/
void 
SceneApp::drawScene()
{
	WindowApp::drawScene();

	// Restore default states, input layout and primitive topology 
	// because mFont->DrawText changes them.  Note that we can 
	// restore the default states by passing null.
	md3dDevice->OMSetDepthStencilState(0, 0);
	float blendFactors[] = {0.0f, 0.0f, 0.0f, 0.0f};
	md3dDevice->OMSetBlendState(0, blendFactors, 0xffffffff);

	//Send View/Proj matrices
	D3DXMATRIX CameraViewMat = *(mCamera.GetViewMatrix());
	D3DXMATRIX CameraProjMat = *(mCamera.GetProjMatrix());

	//Set vertex layout
    md3dDevice->IASetInputLayout(mVertexLayout);
    md3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_LINELIST);

	//Draw
    D3D10_TECHNIQUE_DESC techDesc;
    mTech->GetDesc( &techDesc );
    for(UINT p = 0; p < techDesc.Passes; ++p)
    {
		Draw(mCloth, p, &CameraViewMat, &CameraProjMat);
    }


	if(m_bDrawText)
	{
		RECT R = {5, 5, 0, 0};
		mFont->DrawText(0, mFrameStats.c_str(), -1, &R, DT_NOCLIP, BLACK);
	}

	mSwapChain->Present(0, 0);
}

void 
SceneApp::DeinitialiseGameObjects()
{
	if(mCloth != 0)
	{
		delete mCloth;
		mCloth = 0;
	}
}

/**
*
* This function renders a GameObject.
* (Task ID: -)
*
* @author Declan Wong
* @param _pGameObject. This the GameObject to be drawn.
* @param _iPassCount. This value is the number of passes.
* @param CameraViewMat. This value is the Camera view matrix.
* @param CameraProjMat. This value is the Camera projection matrix.
* @return void.
*
*/
void
SceneApp::Draw(GameObject* _pGameObject, const int _iPassCount, D3DXMATRIX* CameraViewMat, D3DXMATRIX* CameraProjMat)
{					  
	if(_pGameObject != 0)
	{
		if(_pGameObject->GetActive())
		{
			D3DXMATRIX GameObjectMat = *(_pGameObject->GetWorldMat());
			mWVP = GameObjectMat*(*(CameraViewMat) * *(CameraProjMat));
			mfxWorldVar->SetMatrix((float*)&GameObjectMat);
			mfxWVPVar->SetMatrix((float*)&mWVP);
			mTech->GetPassByIndex( _iPassCount )->Apply(0);
			_pGameObject->Draw(md3dDevice);
		}
	}
}

void
SceneApp::ProjectMouse(D3DXVECTOR3& rayOrigin, D3DXVECTOR3& rayDirection)
{
	float pointX, pointY;
	D3DXMATRIX projectionMatrix, viewMatrix, inverseViewMatrix, worldMatrix, translateMatrix, inverseWorldMatrix;
	D3DXVECTOR3 direction, origin;

	// Move the mouse cursor coordinates into the -1 to +1 range.
	pointX = ((2.0f * (float)mfLocalMouseX) / (float)mClientWidth) - 1.0f;
	pointY = (((2.0f * (float)mfLocalMouseY) / (float)mClientHeight) - 1.0f) * -1.0f;
		
	// Adjust the points using the projection matrix to account for the aspect ratio of the viewport.
	projectionMatrix = *(mCamera.GetProjMatrix());
	pointX = pointX / projectionMatrix._11;
	pointY = pointY / projectionMatrix._22;

	// Get the inverse of the view matrix.
	viewMatrix = *(mCamera.GetViewMatrix());
	D3DXMatrixInverse(&inverseViewMatrix, NULL, &viewMatrix);

	// Calculate the direction of the picking ray in view space.
	direction.x = (pointX * inverseViewMatrix._11) + (pointY * inverseViewMatrix._21) + inverseViewMatrix._31;
	direction.y = (pointX * inverseViewMatrix._12) + (pointY * inverseViewMatrix._22) + inverseViewMatrix._32;
	direction.z = (pointX * inverseViewMatrix._13) + (pointY * inverseViewMatrix._23) + inverseViewMatrix._33;

	// Get the origin of the picking ray which is the position of the camera.
	origin = *(mCamera.GetPos());

	// Get the world matrix and translate to the location of the sphere.
	D3DXMatrixIdentity(&worldMatrix);
	//D3DXMatrixTranslation(&translateMatrix, -5.0f, 1.0f, 5.0f);
	//D3DXMatrixMultiply(&worldMatrix, &worldMatrix, &translateMatrix); 

	// Now get the inverse of the translated world matrix.
	D3DXMatrixInverse(&inverseWorldMatrix, NULL, &worldMatrix);

	// Now transform the ray origin and the ray direction from view space to world space.
	D3DXVec3TransformCoord(&rayOrigin, &origin, &inverseWorldMatrix);
	D3DXVec3TransformNormal(&rayDirection, &direction, &inverseWorldMatrix);

	// Normalize the ray direction.
	D3DXVec3Normalize(&rayDirection, &rayDirection);
}

void
SceneApp::IntersectCloth(D3DXVECTOR3 rayOrigin, D3DXVECTOR3 rayDirection, float fHitRadius)
{
	for(int i = 0; i < mCloth->GetTotalLinks(); ++i)
	{
		// Get the point in the centre of the link.
		D3DXVECTOR3 vec3LinkCentre = mCloth->GetLink(i)->GetLinkCenter();

		// Get the vector from the ray origin to the centre of the link.
		D3DXVECTOR3 vec3CameraToVertex = (vec3LinkCentre - rayOrigin);

		float fDistanceCameraToVertex = D3DXVec3Length(&vec3CameraToVertex);

		// Multiply the ray direction by the distance from the ray
		// origin to the centre of the link to get the collision point.
		D3DXVECTOR3 vec3CollisionPointDirection = (rayDirection * fDistanceCameraToVertex);
		
		// Factor in the ray origin to the collision point to get the final collision point.
		D3DXVECTOR3 vec3RayToVertex = rayOrigin + vec3CollisionPointDirection;

		// Get the distance between the centre of the link and the collision point.
		float fDistanceRayToVertex = D3DXVec3Length(&(vec3LinkCentre - vec3RayToVertex));

		// If the distance between the centre of the link and the
		// collision point is less than the minumum hit distance.
		if(fDistanceRayToVertex < fHitRadius)
		{
			mCloth->GetLink(i)->SetTorn(true);
		}
	}
}

void
SceneApp::GrabCloth(D3DXVECTOR3 rayOrigin, D3DXVECTOR3 rayDirection, float fHitRadius)
{
	for(int i = 0; i < mCloth->GetTotalPoints(); ++i)
	{
		// Get the point in the centre of the link.
		D3DXVECTOR3 vec3LinkCentre = *(mCloth->GetPoint(i)->GetCurrentPos());

		// Get the vector from the ray origin to the centre of the link.
		D3DXVECTOR3 vec3CameraToVertex = (vec3LinkCentre - rayOrigin);

		float fDistanceCameraToVertex = D3DXVec3Length(&vec3CameraToVertex);

		// Multiply the ray direction by the distance from the ray
		// origin to the centre of the link to get the collision point.
		D3DXVECTOR3 vec3CollisionPointDirection = (rayDirection * fDistanceCameraToVertex);
		
		// Factor in the ray origin to the collision point to get the final collision point.
		D3DXVECTOR3 vec3RayToVertex = rayOrigin + vec3CollisionPointDirection;

		// Get the distance between the centre of the link and the collision point.
		float fDistanceRayToVertex = D3DXVec3Length(&(vec3LinkCentre - vec3RayToVertex));

		// If the distance between the centre of the link and the
		// collision point is less than the minumum hit distance.
		if(fDistanceRayToVertex < fHitRadius)
		{
			if( !mbPointGrabbed )
			{
				mbPointGrabbed = true;

				mpGrabbedPoint = mCloth->GetPoint(i);
			}
		}
	}
}

void
SceneApp::GetCollisionPoint(D3DXVECTOR3 vec3Pos, D3DXVECTOR3 rayOrigin, D3DXVECTOR3 rayDirection, D3DXVECTOR3& rayCollision)
{
	// Get the point in the centre of the link.
	D3DXVECTOR3 vec3LinkCentre = vec3Pos;

	// Get the vector from the ray origin to the centre of the link.
	D3DXVECTOR3 vec3CameraToVertex = (vec3LinkCentre - rayOrigin);

	float fDistanceCameraToVertex = D3DXVec3Length(&vec3CameraToVertex);

	// Multiply the ray direction by the distance from the ray
	// origin to the centre of the link to get the collision point.
	D3DXVECTOR3 vec3CollisionPointDirection = (rayDirection * fDistanceCameraToVertex);
		
	// Factor in the ray origin to the collision point to get the final collision point.
	rayCollision = rayOrigin + vec3CollisionPointDirection;
}

LRESULT 
SceneApp::msgProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch( msg )
	{
	case WM_KEYUP:
		if(wParam == VK_UP)		mbUpArrow		= false;
		if(wParam == VK_DOWN)	mbDownArrow		= false;
		if(wParam == VK_LEFT)	mbLeftArrow		= false;
		if(wParam == VK_RIGHT)	mbRightArrow	= false;

		if(wParam == 'W')		mbMoveForward	= false;
		if(wParam == 'S')		mbMoveBack		= false;
		if(wParam == 'A')		mbMoveLeft		= false;
		if(wParam == 'D')		mbMoveRight		= false;
		if(wParam == 'R')		mbAscend		= false;
		if(wParam == 'F')		mbDescend		= false;
		if(wParam == 'I')		mbLookDown		= false;
		if(wParam == 'K')		mbLookUp		= false;
		if(wParam == 'J')		mbLookLeft		= false;
		if(wParam == 'L')		mbLookRight		= false;
		if(wParam == 'P')		mbRollLeft		= false;
		if(wParam == VK_OEM_1)	mbRollRight		= false;		
		return(0);

	case WM_KEYDOWN:
		if(wParam == VK_UP)		mbUpArrow		= true;
		if(wParam == VK_DOWN)	mbDownArrow		= true;
		if(wParam == VK_LEFT)	mbLeftArrow		= true;
		if(wParam == VK_RIGHT)	mbRightArrow	= true;

		if(wParam == 'W')		mbMoveForward	= true;
		if(wParam == 'S')		mbMoveBack		= true;
		if(wParam == 'A')		mbMoveLeft		= true;
		if(wParam == 'D')		mbMoveRight		= true;
		if(wParam == 'R')		mbAscend		= true;
		if(wParam == 'F')		mbDescend		= true;
		if(wParam == 'I')		mbLookDown		= true;
		if(wParam == 'K')		mbLookUp		= true;
		if(wParam == 'J')		mbLookLeft		= true;
		if(wParam == 'L')		mbLookRight		= true;
		if(wParam == 'P')		mbRollLeft		= true;
		if(wParam == VK_OEM_1)	mbRollRight		= true;	

		if(wParam == '1')	
		{
			if(mCloth != 0)
			{
				mCloth->Deinitialise();
				mCloth->Initialise(md3dDevice, miClothWidth, miClothHeight);
			}		
		}
		if(wParam == '2')	
		{
			mCamera.ResetCamera();
		}
		if(wParam == '3')	
		{
			mCamera.FreezeMovement();
		}
		if(wParam == '4')	
		{
			mCloth->ToggleWind();
		}
		if(wParam == '9')	
		{

		}	
		if(wParam == '0')
		{

		}

		if(wParam == VK_OEM_MINUS)	
		{
			if(mCloth != 0)
			{
				if( (mCloth->GetPoint(0) != 0) &&
					(mCloth->GetPoint(39) != 0))
				{
					mCloth->GetPoint(0)->GetCurrentPos()->x += 1.0f;
					mCloth->GetPoint(39)->GetCurrentPos()->x -= 1.0f;
				}
			}
		}
		if(wParam == VK_OEM_PLUS)	
		{
			if(mCloth != 0)
			{
				if( (mCloth->GetPoint(0) != 0) &&
					(mCloth->GetPoint(39) != 0))
				{
					mCloth->GetPoint(0)->GetCurrentPos()->x -= 1.0f;
					mCloth->GetPoint(39)->GetCurrentPos()->x += 1.0f;
				}
			}
		}


		if(wParam == VK_RETURN)
		{
			if(mCloth != 0)
			{
				mCloth->ReleaseFixed();
			}
		}
		if(wParam == VK_OEM_3)
		{
			
		}
		if(wParam == VK_TAB)
		{
			m_bDrawText = !m_bDrawText;
		}

		if(wParam == VK_CLEAR)
		{

		}

		if(wParam == VK_F1)
		{

		}
		if(wParam == VK_F2)
		{
			
		}
		if(wParam == VK_F3)
		{
			
		}
		if(wParam == VK_F4)
		{

		}
		if(wParam == VK_F5)
		{

		}

		if(wParam == VK_F9)
		{
			
		}

		if(wParam == VK_BACK)
		{

		}
		if(wParam == VK_ESCAPE) PostQuitMessage(0);
		if(wParam == VK_SPACE)  
		{
			mCamera.ResetCamera();
			if(mCloth != 0)
			{
				mCloth->Deinitialise();
				mCloth->Initialise(md3dDevice, miClothWidth, miClothHeight);
			}
		}
		return(0);

	case WM_MOUSEMOVE:
		{
			mfLocalMouseX = LOWORD(lParam); 
			mfLocalMouseY = HIWORD(lParam); 

			mfWorldMouseX = mfLocalMouseX - (mClientWidth / 2) + mCamera.GetPos()->x;
			mfWorldMouseY = mfLocalMouseY - (mClientHeight / 2) + mCamera.GetPos()->y;
			mfWorldMouseY *= -1;
		}
		return(0);

	case WM_LBUTTONDOWN:
		{
			mbLMBDown = true;
		}
		return(0);
	case WM_RBUTTONDOWN:
		{
			mbRMBDown = true;
		}
		return(0);
	case WM_LBUTTONUP:
		{
			mbLMBDown = false;
			mbPointGrabbed = false;
		}
		return(0);
	case WM_RBUTTONUP:
		{
			mbRMBDown = false;	
		}
		return(0);


		
		return(0);

	// WM_ACTIVATE is sent when the window is activated or deactivated.  
	// We pause the game when the window is deactivated and unpause it 
	// when it becomes active.  
	case WM_ACTIVATE:
		if( LOWORD(wParam) == WA_INACTIVE )
		{
			mAppPaused = true;
			mTimer.stop();
		}
		else
		{
			mAppPaused = false;
			mTimer.start();
		}
		return 0;

	// WM_SIZE is sent when the user resizes the window.  
	case WM_SIZE:
		// Save the new client area dimensions.
		mClientWidth  = LOWORD(lParam);
		mClientHeight = HIWORD(lParam);
		if( md3dDevice )
		{
			if( wParam == SIZE_MINIMIZED )
			{
				mAppPaused = true;
				mMinimized = true;
				mMaximized = false;
			}
			else if( wParam == SIZE_MAXIMIZED )
			{
				mAppPaused = false;
				mMinimized = false;
				mMaximized = true;
				onResize();
			}
			else if( wParam == SIZE_RESTORED )
			{
				
				// Restoring from minimized state?
				if( mMinimized )
				{
					mAppPaused = false;
					mMinimized = false;
					onResize();
				}

				// Restoring from maximized state?
				else if( mMaximized )
				{
					mAppPaused = false;
					mMaximized = false;
					onResize();
				}
				else if( mResizing )
				{
					// If user is dragging the resize bars, we do not resize 
					// the buffers here because as the user continuously 
					// drags the resize bars, a stream of WM_SIZE messages are
					// sent to the window, and it would be pointless (and slow)
					// to resize for each WM_SIZE message received from dragging
					// the resize bars.  So instead, we reset after the user is 
					// done resizing the window and releases the resize bars, which 
					// sends a WM_EXITSIZEMOVE message.
				}
				else // API call such as SetWindowPos or mSwapChain->SetFullscreenState.
				{
					onResize();
				}
			}
		}
		return 0;

	// WM_EXITSIZEMOVE is sent when the user grabs the resize bars.
	case WM_ENTERSIZEMOVE:
		mAppPaused = true;
		mResizing  = true;
		mTimer.stop();
		return 0;

	// WM_EXITSIZEMOVE is sent when the user releases the resize bars.
	// Here we reset everything based on the new window dimensions.
	case WM_EXITSIZEMOVE:
		mAppPaused = false;
		mResizing  = false;
		mTimer.start();
		onResize();
		return 0;
 
	// WM_DESTROY is sent when the window is being destroyed.
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;

	// The WM_MENUCHAR message is sent when a menu is active and the user presses 
	// a key that does not correspond to any mnemonic or accelerator key. 
	case WM_MENUCHAR:
        // Don't beep when we alt-enter.
        return MAKELRESULT(0, MNC_CLOSE);

	// Catch this message so to prevent the window from becoming too small.
	case WM_GETMINMAXINFO:
		((MINMAXINFO*)lParam)->ptMinTrackSize.x = 200;
		((MINMAXINFO*)lParam)->ptMinTrackSize.y = 200; 
		return 0;
	}

	return DefWindowProc(mhMainWnd, msg, wParam, lParam);
}

void SceneApp::buildFX()
{
	DWORD shaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
#if defined( DEBUG ) || defined( _DEBUG )
    shaderFlags |= D3D10_SHADER_DEBUG;
	//shaderFlags |= D3D10_SHADER_SKIP_OPTIMIZATION;
#endif
 
	ID3D10Blob* compilationErrors = 0;
	HRESULT hr = 0;
	hr = D3DX10CreateEffectFromFile(L"Resources/lighting.fx", 0, 0, 
		"fx_4_0", shaderFlags, 0, md3dDevice, 0, 0, &mFX, &compilationErrors, 0);
	if(FAILED(hr))
	{
		if( compilationErrors )
		{
			MessageBoxA(0, (char*)compilationErrors->GetBufferPointer(), 0, 0);
			ReleaseCOM(compilationErrors);
		}
		DXTrace(__FILE__, (DWORD)__LINE__, hr, L"D3DX10CreateEffectFromFile", true);
	} 

	mTech = mFX->GetTechniqueByName("LightTech");

	mfxWVPVar = mFX->GetVariableByName("gWVP")->AsMatrix();
	mfxDeltaVar = mFX->GetVariableByName("gDelta")->AsScalar();

	mfxWorldVar = mFX->GetVariableByName("gWorld")->AsMatrix();
	mfxLightVar = mFX->GetVariableByName("gLight");
	mfxLightTypeVar = mFX->GetVariableByName("gLightType")->AsScalar();
	mfxEyePosWVar = mFX->GetVariableByName("gEyePosW");
}

void 
SceneApp::buildVertexLayouts()
{
	// Create the vertex input layout.
	D3D10_INPUT_ELEMENT_DESC vertexDesc[] =
	{
		{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0},
		{"NORMAL",    0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 12, D3D10_INPUT_PER_VERTEX_DATA, 0},
		{"DIFFUSE",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 24, D3D10_INPUT_PER_VERTEX_DATA, 0},
		{"SPECULAR",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 40, D3D10_INPUT_PER_VERTEX_DATA, 0}
	};

	// Create the input layout
    D3D10_PASS_DESC PassDesc;
    mTech->GetPassByIndex(0)->GetDesc(&PassDesc);
    HR(md3dDevice->CreateInputLayout(vertexDesc, 4, PassDesc.pIAInputSignature,
		PassDesc.IAInputSignatureSize, &mVertexLayout));
}
