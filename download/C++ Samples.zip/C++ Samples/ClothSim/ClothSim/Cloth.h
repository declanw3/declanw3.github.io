//
//  Diploma of Interactive Gaming
//  Media Design School
//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Cloth.h
//  Description :   Header for the Cloth class
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

#ifndef __CLOTH_H__
#define __CLOTH_H__

// Library Includes
// Local Includes
#include "Utility.h"
#include "GameObject.h"

// Types
// Constants
// Prototypes

class Point;
class Link;
class Line;
class Cloth : public GameObject
{
	// Member Variables
public:
protected:
private:
	int m_iWidth;
	int m_iHeight;
	int m_iTotalPoints;
	int m_iTotalLinks;

	float m_fFloorY;

	Point** m_pPoints;
	Link** m_pLinks;
	Line* m_pLine;

	bool m_bWind;

	// Member Functions
public:
	Cloth();
	~Cloth();

	bool Initialise(ID3D10Device* device, const int _kiWidth, const int _kiHeight);
	void Deinitialise();
	void Update(float dt);
	void Draw(ID3D10Device* device);

	void ReleaseFixed();
	void ProcessFloor();

	const int GetTotalPoints();
	Point* GetPoint(const int _iIndex);

	const int GetTotalLinks();
	Link* GetLink(const int _iIndex);

	void ToggleWind();

protected:
private:
};

#endif //__CLOTH_H__