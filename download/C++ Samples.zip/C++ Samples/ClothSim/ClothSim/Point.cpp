//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Point.cpp
//  Description :   Point implementation file
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

// Library Includes
// Local Includes
// This Include
#include "Point.h"

// Static Variables
// Static Function Prototypes
// Implementation

Point::Point()
:m_fMass(1.0f)
,m_fDamping(0.8f)
,m_bFixed(false)
{
	ZeroMemory(m_vec3CurrentPos, sizeof(D3DXVECTOR3));
	ZeroMemory(m_vec3PreviousPos, sizeof(D3DXVECTOR3));
	ZeroMemory(m_vec3Acceleration, sizeof(D3DXVECTOR3));
}			   

Point::~Point()
{

}

/**
*
* This function updates the Point per frame.
* (Task ID: -)
*
* @author Declan Wong
* @param dt. This the delta time scalar.
* @return void.
*
*/
void 
Point::Update(float dt)
{
	VerletIntegration(dt);
}

void 
Point::VerletIntegration(float dt)
{
	if( !m_bFixed )
	{
		D3DXVECTOR3 vec3Vel = m_vec3CurrentPos - m_vec3PreviousPos;
		m_vec3PreviousPos = m_vec3CurrentPos;
		m_vec3CurrentPos += vec3Vel * ( 1.0f - m_fDamping ) + m_vec3Acceleration * dt * dt; 
		m_vec3Acceleration = vec3Vel * dt;
	}
}

void 
Point::ApplyForce(D3DXVECTOR3 _vec3Force)
{
	m_vec3Acceleration += _vec3Force / m_fMass;
}

D3DXVECTOR3* 
Point::GetCurrentPos()
{
	return(&m_vec3CurrentPos);
}

void 
Point::SetCurrentPos(D3DXVECTOR3 _vec3CurrentPos)
{
	m_vec3CurrentPos = _vec3CurrentPos;
}

D3DXVECTOR3* 
Point::GetPreviousPos()
{
	return(&m_vec3PreviousPos);
}

void 
Point::SetPreviousPos(D3DXVECTOR3 _vec3PreviousPos)
{
	m_vec3PreviousPos = _vec3PreviousPos;
}

D3DXVECTOR3* 
Point::GetAcceleration()
{
	return(&m_vec3Acceleration);
}

void 
Point::SetAcceleration(D3DXVECTOR3 _vec3Acceleration)
{
	m_vec3Acceleration = _vec3Acceleration;
}

const float 
Point::GetMass()
{
	return(m_fMass);
}

void 
Point::SetMass(const float _fMass)
{
	m_fMass = _fMass;
}

const bool 
Point::GetFixed()
{
	return(m_bFixed);
}

void 
Point::SetFixed(const bool _bFixed)
{
	m_bFixed = _bFixed;
}