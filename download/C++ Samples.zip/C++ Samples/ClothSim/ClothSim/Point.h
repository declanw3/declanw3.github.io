//
//  Diploma of Interactive Gaming
//  Media Design School
//  Auckland
//  New Zealand
//
//  (c) 2013 Media Design School
//
//  File Name   :   Point.h
//  Description :   Header for the Point class
//  Author      :   Declan Wong
//  Mail        :   declan.wong@mediadesign.school.nz
//

#ifndef __POINT_H__
#define __POINT_H__

// Library Includes
// Local Includes
#include "Utility.h"

// Types
// Constants
// Prototypes

class Point
{
	// Member Variables
public:
protected:
private:
	D3DXVECTOR3 m_vec3CurrentPos;
	D3DXVECTOR3 m_vec3PreviousPos;
	D3DXVECTOR3 m_vec3Acceleration;

	float m_fMass;
	float m_fDamping;
	bool m_bFixed;

	// Member Functions
public:
	Point();
	~Point();

	void Update(float dt);
	void VerletIntegration(float dt);
	void ApplyForce(D3DXVECTOR3 _vec3Force);

	D3DXVECTOR3* GetCurrentPos();
	void SetCurrentPos(D3DXVECTOR3 _vec3CurrentPos);

	D3DXVECTOR3* GetPreviousPos();
	void SetPreviousPos(D3DXVECTOR3 _vec3PreviousPos);

	D3DXVECTOR3* GetAcceleration();
	void SetAcceleration(D3DXVECTOR3 _vec3Acceleration);

	const float GetMass();
	void SetMass(const float _fMass);

	const bool GetFixed();
	void SetFixed(const bool _bFixed);

protected:
private:
};

#endif //__POINT_H__