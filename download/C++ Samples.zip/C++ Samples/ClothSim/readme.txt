Cloth simulation demonstrating Verlet Intergration and constraints.

Controls:
TAB - Minimise controls
SPACE - Reset application
ENTER - Break fixed points
ESC -  Quit application
PLUS - Move fixed points away
MINUS - Move fixed points together
LMB - Drag Cloth
RMB - Tear Cloth
1 - Reset Camera
2 - Reset Cloth
3 - Stop camera movement
4 - Toggle wind

W - Camera forward
S - Camera backward
A - Camera left
D - Camera right
R - Camera fly
F - Camera descend
I - Camera look down
K - Camera look up	
J - Camera look left
L - Camera look right

