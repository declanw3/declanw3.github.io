

#ifndef VERTEX_H
#define VERTEX_H

struct Vertex
{
	D3DXVECTOR3 pos;
	D3DXCOLOR   color;

	Vertex()
	{
		ZeroMemory(&pos, sizeof(D3DXVECTOR3));
		ZeroMemory(&color, sizeof(D3DXCOLOR));
	}

	Vertex(D3DXVECTOR3 _pos)
	{
		pos = _pos;
	}

	Vertex(float _fX, float _fY, float _fZ)
	{
		pos.x = _fX;
		pos.y = _fY;
		pos.z = _fZ;

		ZeroMemory(&color, sizeof(D3DXCOLOR));
	}

	Vertex(D3DXVECTOR3 _pos, D3DXCOLOR _color)
	{
		pos = _pos;
		color = _color;
	}

	Vertex(float _fX, float _fY, float _fZ,
			float _fR, float _fG, float _fB, float _fA)
	{
		pos.x = _fX;
		pos.y = _fY;
		pos.z = _fZ;

		color.r = _fR;
		color.g = _fG;
		color.b = _fB;
		color.a = _fA;
	}
};

#endif //VERTEX_H