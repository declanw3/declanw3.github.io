#include "ContactListener.h"
#include "World.h"

ContactListener::ContactListener()
:m_pWorldRef(0)
{

}

ContactListener::~ContactListener()
{
	m_pWorldRef = 0;
}

const bool 
ContactListener::Initialise(World* _pWorldRef)
{
	bool bSuccess = false;
	m_pWorldRef = 0;

	if(_pWorldRef != 0)
	{
		m_pWorldRef = _pWorldRef;

		bSuccess = true;
	}

	return(bSuccess);
}

void 
ContactListener::BeginContact(b2Contact* contact) 
{
  
}
  
void 
ContactListener::EndContact(b2Contact* contact)
{
  	char* bodyUserDataA = reinterpret_cast<char*>( contact->GetFixtureA()->GetBody()->GetUserData() );
	char* bodyUserDataB = reinterpret_cast<char*>( contact->GetFixtureB()->GetBody()->GetUserData() );

	if(bodyUserDataA != 0)
	{
		if(bodyUserDataB != 0)
		{
			if( (strcmp(bodyUserDataA, "GrumpyBird") == 0) && (strcmp(bodyUserDataB, "EnemyBird") == 0) ||
				(strcmp(bodyUserDataA, "GrumpyBird") == 0) && (strcmp(bodyUserDataB, "GlassWall") == 0))
			{
				b2Body* pBodyA = contact->GetFixtureA()->GetBody();
				b2Body* pBodyB = contact->GetFixtureB()->GetBody();

				float fGrumpyBirdVel = pBodyA->GetLinearVelocity().LengthSquared();
				float fObjectVel = pBodyB->GetLinearVelocity().LengthSquared();
				float fVel = max(fGrumpyBirdVel, fObjectVel);
				if(fVel > 200.0f)
				{
					m_pWorldRef->DestroyBox2DObject(reinterpret_cast<char*>(contact->GetFixtureB()->GetUserData()));

					if(strcmp(bodyUserDataB, "EnemyBird") == 0)
					{
						m_pWorldRef->DecrementEnemyCount();
					}
				}
			}

			if( (strcmp(bodyUserDataA, "RigidBody") == 0) && (strcmp(bodyUserDataB, "EnemyBird") == 0) ||
				(strcmp(bodyUserDataA, "RigidBody") == 0) && (strcmp(bodyUserDataB, "GlassWall") == 0))
			{
				b2Body* pBodyA = contact->GetFixtureA()->GetBody();
				b2Body* pBodyB = contact->GetFixtureB()->GetBody();

				float fRigidBodyVel = pBodyA->GetLinearVelocity().LengthSquared();
				float fObjectVel = pBodyB->GetLinearVelocity().LengthSquared();
				float fVel = max(fRigidBodyVel, fObjectVel);

				if(fVel > 200.0f)
				{
					m_pWorldRef->DestroyBox2DObject(reinterpret_cast<char*>(contact->GetFixtureB()->GetUserData()));

					if(strcmp(bodyUserDataB, "EnemyBird") == 0)
					{
						m_pWorldRef->DecrementEnemyCount();
					}
				}
			}

			if( (strcmp(bodyUserDataA, "GlassWall") == 0) && (strcmp(bodyUserDataB, "RigidBody") == 0) ||
				(strcmp(bodyUserDataA, "GlassWall") == 0) && (strcmp(bodyUserDataB, "GrumpyBird") == 0) ||
				(strcmp(bodyUserDataA, "GlassWall") == 0) && (strcmp(bodyUserDataB, "EnemyBird") == 0) ||
				(strcmp(bodyUserDataA, "GlassWall") == 0) && (strcmp(bodyUserDataB, "GlassWall") == 0))
			{
				b2Body* pBodyA = contact->GetFixtureA()->GetBody();
				b2Body* pBodyB = contact->GetFixtureB()->GetBody();

				float fGlassWallVel = pBodyA->GetLinearVelocity().LengthSquared();
				float fObjectVel = pBodyB->GetLinearVelocity().LengthSquared();
				float fVel = max(fGlassWallVel, fObjectVel);
				if( fVel > 200.0f )
				{
					if( (strcmp(bodyUserDataB, "EnemyBird") == 0) ||
						(strcmp(bodyUserDataB, "GlassWall") == 0) ) 
					{
						m_pWorldRef->DestroyBox2DObject(reinterpret_cast<char*>(contact->GetFixtureB()->GetUserData()));
					}

					m_pWorldRef->DestroyBox2DObject(reinterpret_cast<char*>(contact->GetFixtureA()->GetUserData()));

					if(strcmp(bodyUserDataB, "EnemyBird") == 0)
					{
						m_pWorldRef->DecrementEnemyCount();
					}
				}
			}

			if( (strcmp(bodyUserDataA, "EnemyBird") == 0) && (strcmp(bodyUserDataB, "RigidBody") == 0) ||
				(strcmp(bodyUserDataA, "EnemyBird") == 0) && (strcmp(bodyUserDataB, "GrumpyBird") == 0) ||
				(strcmp(bodyUserDataA, "EnemyBird") == 0) && (strcmp(bodyUserDataB, "EnemyBird") == 0) ||
				(strcmp(bodyUserDataA, "EnemyBird") == 0) && (strcmp(bodyUserDataB, "GlassWall") == 0))
			{
				b2Body* pBodyA = contact->GetFixtureA()->GetBody();
				b2Body* pBodyB = contact->GetFixtureB()->GetBody();				

				float fEnemyBirdVel = pBodyA->GetLinearVelocity().LengthSquared();
				float fObjectVel = pBodyB->GetLinearVelocity().LengthSquared();
				float fVel = max(fEnemyBirdVel, fObjectVel);
				if( fVel > 200.0f )
				{
					if( (strcmp(bodyUserDataB, "EnemyBird") == 0) ||
						(strcmp(bodyUserDataB, "GlassWall") == 0) ) 
					{
						m_pWorldRef->DestroyBox2DObject(reinterpret_cast<char*>(contact->GetFixtureB()->GetUserData()));
					}

					m_pWorldRef->DestroyBox2DObject(reinterpret_cast<char*>(contact->GetFixtureA()->GetUserData()));

					m_pWorldRef->DecrementEnemyCount();

					if(strcmp(bodyUserDataB, "EnemyBird") == 0)
					{
						m_pWorldRef->DecrementEnemyCount();
					}
				}
			}
		}
	}
}

void
ContactListener::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
{

}

void 
ContactListener::PostSolve(b2Contact* contact, const b2ContactImpulse* impulse)
{

}