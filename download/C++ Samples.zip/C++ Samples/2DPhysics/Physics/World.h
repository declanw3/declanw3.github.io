#ifndef __WORLD_H__
#define __WORLD_H__

#include <Box2D\Box2D.h>

#include "Utility.h"
#include "ContactListener.h"

struct TGrumpyBird
{
	TGrumpyBird()
	:bFired(false)
	,bSpecialUsed(false)
	{

	};

	~TGrumpyBird()
	{

	};

	bool bFired;
	bool bSpecialUsed;
};

enum EGrumpyBird
{
	INVALID_GRUMPYBIRD = -1,

	GRUMPYBIRD_ONE,
	GRUMPYBIRD_TWO,
	GRUMPYBIRD_THREE,

	MAX_GRUMPYBIRD
};

enum EScene
{
	INVALID_SCENE = -1, 

	SCENE_ONE,
	SCENE_TWO,

	MAX_SCENE
};

enum EGameState
{
	INVALID_GAMESTATE = -1,

	GAMESTATE_PLAYING,
	GAMESTATE_WIN,
	GAMESTATE_LOSE,
	GAMESTATE_POST,

	MAX_GAMESTATE
};

class Box2DObject;
class GameObject;
class World
{
public:
	World();
	~World();

	bool Intialise(ID3D10Device* device);
	bool Deinitialise();

	void Update(float dt);
	void Draw(ID3D10Device* device);

	bool InitialiseGrumpyBirds(ID3D10Device* device, int& _riBox2DObjectCount);
	bool InitialiseWalls(ID3D10Device* device, int& _riBox2DObjectCount);

	bool InitialiseScene1Objects(ID3D10Device* device, int& _riBox2DObjectCount, int& _riRenderObjectCount);
	bool InitialiseScene2Objects(ID3D10Device* device, int& _riBox2DObjectCount, int& _riRenderObjectCount);

	void RenderLine(GameObject* _pGameObject, b2Body* _pBody1, b2Body* _pBody2); 

	const int GetMaxBox2DObjects();
	Box2DObject* GetBox2DObject(const int _iIndex);
	Box2DObject* GetBox2DObjectByID(const char* _kcID);
	b2Body* GetBodyByID(const char* _kcID);
	const int GetMaxRenderObjects();
	GameObject* GetRenderObject(const int _iIndex);

	const bool DestroyBox2DObject(const char* _kcID);
	void SweepDeadBox2DObjects();

	const EScene GetActiveScene();
	void SetActiveScene(const EScene _eActiveScene);
	const EGrumpyBird GetActiveBird();
	void SetActiveBird(const EGrumpyBird _eActiveBird);

	TGrumpyBird* GetGrumpyBird(const int _kiIndex);

	void IncrementActiveBird();
	void DecrementEnemyCount();
	const bool CheckGameState();
	void SetGameState(const EGameState _eGameState);
	const EGameState GetGameState();

protected:
private:
	//const int32 k_maxContactPoints = 2048;

	b2Body* m_groundBody;
	b2AABB m_worldAABB;
	//ContactPoint m_points[k_maxContactPoints];
	int32 m_pointCount;
	//DestructionListener m_destructionListener;
	//DebugDraw m_debugDraw;
	int32 m_textLine;
	b2World* m_world;
	b2Body* m_bomb;
	b2MouseJoint* m_mouseJoint;
	b2Vec2 m_bombSpawnPoint;
	bool m_bombSpawning;
	b2Vec2 m_mouseWorld;
	int32 m_stepCount;

	b2Profile m_maxProfile;
	b2Profile m_totalProfile;



	const int m_kiMaxSceneObjects;
	Box2DObject** m_pBox2DObjects;
	const int m_kiMaxRenderObjects;
	GameObject** m_pRenderObjects;	//Lines etc.

	b2ContactListener* m_pContactListener;

	EScene m_eActiveScene;
	EGrumpyBird m_eActiveBird;
	TGrumpyBird** m_pGrumpyBirds;

	const int m_kiMaxEnemyBirds;
	int m_iEnemyBirdCount;
	EGameState m_eGameState;
	bool m_bGameOver;

public:
protected:
private:
};

#endif //__WORLD_H__