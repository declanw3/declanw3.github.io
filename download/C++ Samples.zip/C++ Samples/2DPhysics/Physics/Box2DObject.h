#ifndef __BOX2DOBJECT_H__
#define __BOX2DOBJECT_H__

#include <string>

#include "Shape.h"

const float g_kfPositionScale = 5.0f;

class GameObject;
class Box2DObject
{
public:
	Box2DObject();
	~Box2DObject();
	
	const bool Initialise();

	void Update(float dt);
	void Draw();

	const bool AddBody(b2World* _pWorld, b2BodyDef _BodyDef);
	const bool AddFixture(b2FixtureDef _FixtureDef);
	const bool AddGameObjectShape(ID3D10Device* device, EShape _eShapeType, D3DXCOLOR _color = D3DXCOLOR(0.0f, 0.0f, 0.0f, 0.0f), const float _kfWidth = 1.0f, const float kfHeight = 1.0f);
	
	const bool SetID(const char* _kcID);
	const char* GetID();

	b2Body* GetBody();
	GameObject* GetGameObject();

protected:
private:

public:
protected:
private:
	b2Body* m_pBody;
	GameObject* m_pGameObject;
	std::string m_strID;
};

#endif //__BOX2DOBJECT_H__