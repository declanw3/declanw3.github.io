#include <Box2D\Box2D.h>

#include "Box2DObject.h"
#include "GameObject.h"

Box2DObject::Box2DObject()
:m_pBody(0)
,m_pGameObject(0)
{
	m_strID = "NULL";
}

Box2DObject::~Box2DObject()
{
	if(m_pGameObject != 0)
	{
		delete m_pGameObject;
		m_pGameObject = 0;
	}
}

	
const bool 
Box2DObject::Initialise()
{
	bool bSuccess = false;

	if(m_pGameObject == 0)
	{
		m_pGameObject = new GameObject();

		bSuccess = true;
	}

	return(bSuccess);
}

void 
Box2DObject::Update(float dt)
{
	if(m_pBody != 0)
	{
		if(m_pGameObject != 0)
		{

			b2Vec2 vec2Pos = m_pBody->GetPosition();
			D3DXVECTOR3 vec3Pos = D3DXVECTOR3(vec2Pos.x, vec2Pos.y, 0.0f);
			vec3Pos *= g_kfPositionScale;
			m_pGameObject->SetPosition(vec3Pos);
			m_pGameObject->SetRoll( m_pBody->GetAngle() );

			m_pGameObject->Update(dt);
			
		}
	}
}

void 
Box2DObject::Draw()
{

}


const bool 
Box2DObject::AddBody(b2World* _pWorld, b2BodyDef _BodyDef)
{
	m_pBody = _pWorld->CreateBody(&_BodyDef);

	return(false);
}

const bool 
Box2DObject::AddFixture(b2FixtureDef _FixtureDef)
{
	bool bSuccess = false;

	if(m_pBody != 0)
	{
		m_pBody->CreateFixture(&_FixtureDef);

		bSuccess = true;
	}

	return(bSuccess);
}

const bool 
Box2DObject::AddGameObjectShape(ID3D10Device* device, EShape _eShapeType, D3DXCOLOR _color, const float _kfWidth, const float kfHeight)
{
	bool bSuccess = false;

	if(m_pGameObject != 0)
	{
		m_pGameObject->InitialiseShape(device, _eShapeType, _color, _kfWidth, kfHeight);

		bSuccess = true;
	}

	return(bSuccess);
}

const bool
Box2DObject::SetID(const char* _kcID)
{
	m_strID = _kcID;

	return(false);
}

const char*
Box2DObject::GetID()
{
	return(m_strID.c_str());
}


b2Body* 
Box2DObject::GetBody()
{
	return(m_pBody);
}

GameObject* 
Box2DObject::GetGameObject()
{
	return(m_pGameObject);
}
