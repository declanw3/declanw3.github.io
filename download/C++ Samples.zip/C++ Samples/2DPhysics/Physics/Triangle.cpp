#include "Triangle.h"
#include "Vertex.h"

Triangle::Triangle()
{

}

Triangle::~Triangle()
{

}

const bool
Triangle::Initialise(ID3D10Device* device, D3DXCOLOR _color, bool _bIndexed)
{
	bool bSuccess = false;

	//Assign device
	md3dDevice = device;

	//Triangle mesh data
	m_iVertexCount = 3;
	m_iIndexCount = 3;

	//Create Vertex Buffer
	//Populate VertexData
	if(mVB == 0)
	{
		Vertex vertices[3] = {Vertex(D3DXVECTOR3(-0.5f, -0.5f, 0.0f), _color), //Triangle left leg
								Vertex(D3DXVECTOR3(0.0f, 0.5f, 0.0f), _color),//Triangle head
								Vertex(D3DXVECTOR3(0.5f, -0.5f, 0.0f), _color)}; //Triangle right leg

		D3D10_BUFFER_DESC vbd;
		vbd.Usage = D3D10_USAGE_IMMUTABLE;
		vbd.ByteWidth = sizeof(Vertex) * m_iVertexCount;
		vbd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
		vbd.CPUAccessFlags = 0;
		vbd.MiscFlags = 0;
		D3D10_SUBRESOURCE_DATA vinitData;
		vinitData.pSysMem = vertices;
		HR(md3dDevice->CreateBuffer(&vbd, &vinitData, &mVB));
	}


	//Create the index buffer
	// Populate IndexData
	if(_bIndexed)
	{
		if(mIB == 0)
		{
			DWORD indices[3] = {0, //Triangle left leg
								1, //Triangle head
								2}; //Triangle right leg


			D3D10_BUFFER_DESC ibd;
			ibd.Usage = D3D10_USAGE_IMMUTABLE;
			ibd.ByteWidth = sizeof(DWORD) * m_iIndexCount;
			ibd.BindFlags = D3D10_BIND_INDEX_BUFFER;
			ibd.CPUAccessFlags = 0;
			ibd.MiscFlags = 0;
			D3D10_SUBRESOURCE_DATA iinitData;
			iinitData.pSysMem = indices;
			HR(md3dDevice->CreateBuffer(&ibd, &iinitData, &mIB));
		}
	}

	return(bSuccess);
}

void 
Triangle::Draw(ID3D10Device* device)
{
    md3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shape::Draw(device);
}