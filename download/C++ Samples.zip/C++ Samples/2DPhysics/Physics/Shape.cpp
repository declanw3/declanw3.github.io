#include "Shape.h"
#include "Vertex.h"

ID3D10Device* Shape::md3dDevice = 0;	//Device

Shape::Shape()
: mVB(0)
, mIB(0)
{

}

Shape::~Shape()
{
	ReleaseCOM(mVB);
	ReleaseCOM(mIB);
}

void
Shape::Update(float dt)
{

}

void 
Shape::Draw(ID3D10Device* device)
{
	UINT stride = sizeof(Vertex);
	UINT offset = 0;
	md3dDevice->IASetVertexBuffers(0, 1, &mVB, &stride, &offset);

	if(mIB != 0)
	{
		md3dDevice->IASetIndexBuffer(mIB, DXGI_FORMAT_R32_UINT, 0);
		md3dDevice->DrawIndexed(m_iIndexCount, 0, 0);
	}
	else
	{
		md3dDevice->Draw(m_iVertexCount, 0); 
	}
}