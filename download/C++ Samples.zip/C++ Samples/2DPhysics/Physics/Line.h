#include "Utility.h"
#include "Shape.h"

#ifndef _LINE_H
#define _LINE_H

class Line : public Shape
{
public:
	Line();
	~Line();
	
	const bool Initialise(ID3D10Device* device, D3DXCOLOR _color, bool _bIndexed);
	void Draw(ID3D10Device* device);

protected:
private:

public:
protected:
private:
};

#endif //_TRIANGLE_H_