#include "GameObject.h"
#include "Line.h"
#include "Triangle.h"
#include "Circle.h"
#include "Rectangle.h"

GameObject::GameObject()
: mfYaw(0.0f)
, mfPitch(0.0f)
, mfRoll(0.0f)
, m_fScale(0.0f)
, m_pShape(0)
, m_iMaxComponents(0)
, m_pComponents(0)
,m_bActive(true)
{
	D3DXMatrixIdentity(&mWorldMat);
	ZeroMemory(&mPos, sizeof(D3DXVECTOR3));
	ZeroMemory(&mDir, sizeof(D3DXVECTOR3));

	m_fScale = 1.0f;

	m_strID = "NULL";
}

GameObject::~GameObject()
{
	if(m_pShape != 0)
	{
		//m_pShape->Deinitialise();
		delete m_pShape;
		m_pShape = 0;
	}

	if(m_pComponents != 0)
	{
		for(int i = 0; i < m_iMaxComponents; ++i)
		{
			if(m_pComponents[i] != 0)
			{
				if(m_pComponents[i]->m_pShape != 0)
				{
					//m_pComponents[i]->m_pShape->Deinitialise();
				}
				delete m_pComponents[i];
				//m_pComponents = 0;
			}
		}

		delete[] m_pComponents;
		m_pComponents = 0;
	}
}

const bool
GameObject::InitialiseShape(ID3D10Device* device, EShape _eShapeType, D3DXCOLOR _color, const float _kfWidth, const float _kfHeight)
{
	bool bSuccess = false;

	if(m_pShape == 0)
	{
		switch(_eShapeType)
		{
		case SHAPE_LINE:
			{
				m_pShape = new Line();
				if(m_pShape != 0)
				{
					m_pShape->Initialise(device, _color, false);
				}
			}
			break;

		case SHAPE_TRIANGLE:
			{
				m_pShape = new Triangle();
				if(m_pShape != 0)
				{
					m_pShape->Initialise(device, _color, false);
				}
			}
			break;

		case SHAPE_CIRCLE:
			{
				m_pShape = new Circle(20);
				if(m_pShape != 0)
				{
					m_pShape->Initialise(device, _color, false);
				}
			}
			break;

		case SHAPE_RECTANGLE:
			{
				m_pShape = new CRectangle(_kfWidth, _kfHeight);
				if(m_pShape != 0)
				{
					m_pShape->Initialise(device, _color, false);
				}
			}
			break;

		default:break;
		}
	}

	return(bSuccess);
}

const bool 
GameObject::InitialiseComponents(ID3D10Device* device)
{
	return(false);
}

void
GameObject::Update(float dt)
{
	D3DXMATRIX matRotation;
	D3DXMatrixRotationZ(&matRotation, mfRoll);

	D3DXMATRIX matTranslation;
	D3DXMatrixTranslation(&matTranslation, mPos.x, mPos.y, mPos.z);

	D3DXMatrixMultiply(&mWorldMat, &matRotation, &matTranslation);


	D3DXMATRIX matScaling;
	D3DXMatrixScaling(&matScaling, m_fScale, m_fScale, m_fScale);
	D3DXMatrixMultiply(&mWorldMat, &matScaling, &mWorldMat);

	for(int i = 0; i < m_iMaxComponents; ++i)
	{
		if(m_pComponents != 0)
		{
			if(m_pComponents[i] != 0)
			{
				m_pComponents[i]->Update(dt);
				//m_pComponents[i]->Draw(device);
			}
		}
	}
}

void 
GameObject::Draw(ID3D10Device* device)
{
	if(m_pShape != 0)
	{
		m_pShape->Draw(device);
	}
}

const bool
GameObject::AddComponent(ID3D10Device* device, EShape _eShapeType, D3DXCOLOR _color)
{
	bool bSuccess = false;

	++m_iMaxComponents;

	if(m_pComponents != 0)
	{
		// Populate VertexData
		GameObject** newSecondaries = new GameObject*[m_iMaxComponents];

		for(int i = 0; i < m_iMaxComponents - 1; ++i)
		{
			newSecondaries[i] = m_pComponents[i];
		}

		newSecondaries[m_iMaxComponents - 1] = new GameObject;
		if(newSecondaries[m_iMaxComponents - 1] != 0)
		{
			newSecondaries[m_iMaxComponents - 1]->InitialiseShape(device, _eShapeType, _color);
		}

		if(m_pComponents != 0)
		{
			delete[] m_pComponents;
			m_pComponents = 0;
		}

		m_pComponents = newSecondaries;
	}
	else
	{
		m_pComponents = new GameObject*[m_iMaxComponents];
		m_pComponents[m_iMaxComponents - 1] = new GameObject;
		if(m_pComponents[m_iMaxComponents - 1] != 0)
		{
			m_pComponents[m_iMaxComponents - 1]->InitialiseShape(device, _eShapeType, _color);
		}
	}

	return(bSuccess);
}

GameObject* 
GameObject::GetComponent(const int _iIndex)
{
	GameObject* pSecondary = 0;

	if( (_iIndex >= 0) && (_iIndex < m_iMaxComponents) )
	{
		pSecondary = m_pComponents[_iIndex];
	}

	return(pSecondary);
}

const bool 
GameObject::HasComponents()
{
	bool bComponents = false;

	if(m_pComponents != 0)
	{
		bComponents = true;
	}

	return(bComponents);
}

const int
GameObject::GetMaxComponents()
{
	return(m_iMaxComponents);
}

void
GameObject::SetScale(const float _fScale)
{
	m_fScale = _fScale;
}

void 
GameObject::SetRoll(const float _fRoll)
{
	mfRoll = _fRoll;
}

const D3DXMATRIX*
GameObject::GetWorldMat()
{
	return(&mWorldMat);
}

const D3DXVECTOR3*
GameObject::GetPosition()
{
	return(&mPos);
}

void 
GameObject::SetPosition(const D3DXVECTOR3& _vecPos)
{
	mPos = _vecPos;
}

const char*
GameObject::GetID()
{
	return(m_strID.c_str());
}

const bool
GameObject::SetID(const char* _kcID)
{
	m_strID = _kcID;

	return(false);
}

const bool
GameObject::GetActive()
{
	return(m_bActive);
}

void 
GameObject::SetActive(const bool _bActive)
{
	m_bActive = _bActive;
}