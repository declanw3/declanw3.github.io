#include "Utility.h"

#ifndef _SHAPE_H_
#define _SHAPE_H_

typedef enum EShape
{
	INVALID_SHAPE = -1,

	SHAPE_LINE,
	SHAPE_TRIANGLE,
	SHAPE_CIRCLE,
	SHAPE_RECTANGLE,
	
	MAX_SHAPES
} EShape;

class Shape
{
public:
	Shape();
	~Shape();

	virtual const bool Initialise(ID3D10Device* device, D3DXCOLOR _color, bool _bIndexed) = 0;
	virtual void Update(float dt);
	virtual void Draw(ID3D10Device* device);

protected:
private:

public:
protected:
	static ID3D10Device* md3dDevice;	//Device
	ID3D10Buffer* mVB;					//Vertex buffer
	ID3D10Buffer* mIB;					//Index buffer

	int m_iVertexCount;
	int m_iIndexCount;

private:
};

#endif //_SHAPE_H_