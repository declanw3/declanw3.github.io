#include "Camera.h"

Camera::Camera()
// Set Members to invalid values
:m_fPitch(0.0f)
,m_fYaw(0.0f)
,m_fRoll(0.0f)
{
	// Set all matrices to identity.
	D3DXMatrixIdentity(&m_matView);
	D3DXMatrixIdentity(&m_matProj);

	D3DXMatrixIdentity(&m_matPreviousVP);

	ZeroMemory(&m_vecPos, sizeof(D3DXVECTOR3));
	ZeroMemory(&m_vecUp, sizeof(D3DXVECTOR3));
	ZeroMemory(&m_vecRight, sizeof(D3DXVECTOR3));
	ZeroMemory(&m_vecDir, sizeof(D3DXVECTOR3));

	ResetCamera();
}

Camera::~Camera()
{

}

void Camera::Update(float dt)
{
	//Update Velocity
 	m_fMoveVel += m_fMoveAccel;
	m_fStrafeVel += m_fStrafeAccel;
	m_fFlyVel += m_fFlyAccel;
	m_fYawVel += m_fYawAccel;
	m_fPitchVel += m_fPitchAccel;
	m_fRollVel += m_fRollAccel;

	Move();
	Strafe();
	Fly();
	Yaw();
	Pitch();
	Roll();

	m_fMoveAccel *= dt * 0.95f;
	if(m_fMoveAccel == 0.0f)
	{
		m_fMoveVel *= 0.999f;
	}

	m_fStrafeAccel *= dt * 0.95f;
	if(m_fStrafeAccel == 0.0f)
	{
		m_fStrafeVel *= 0.999f;
	}

	m_fFlyAccel *= dt * 0.95f;
	if(m_fFlyAccel == 0.0f)
	{
		m_fFlyVel *= 0.999f;
	}


	m_fYawAccel *= dt * 0.99f;
	if(m_fYawAccel == 0.0f)
	{
		m_fYawVel *= 0.999f;
	}

	m_fPitchAccel *= dt * 0.99f;
	if(m_fPitchAccel == 0.0f)
	{
		m_fPitchVel *= 0.999f;
	}

	m_fRollAccel *= dt * 0.99f;
	if(m_fRollAccel == 0.0f)
	{
		m_fRollVel *= 0.999f;
	}



	SetPreviousVP();

	// Convert between LookAt and setting the 3D view.
	m_vecUp = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	m_vecDir = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
	m_vecRight = D3DXVECTOR3(1.0f, 0.0f, 0.0f);


	// Yaw rotation about the YAxis
	D3DXMATRIX matYaw;
	D3DXMatrixRotationAxis(&matYaw, &m_vecUp, m_fYaw);
	// Apply transformation against the YawMatrix
	D3DXVec3TransformCoord(&m_vecDir, &m_vecDir, &matYaw); 
	D3DXVec3TransformCoord(&m_vecRight, &m_vecRight, &matYaw); 

	// Roll rotation about the XAxis
	D3DXMATRIX matPitch;
	D3DXMatrixRotationAxis(&matPitch, &m_vecRight, m_fPitch);
	// Apply transformation against the RollMatrix
	D3DXVec3TransformCoord(&m_vecDir, &m_vecDir, &matPitch); 
	D3DXVec3TransformCoord(&m_vecUp, &m_vecUp, &matPitch); 
		
	// Roll rotation about the ZAxis
	D3DXMATRIX matRoll;
	D3DXMatrixRotationAxis(&matRoll, &m_vecDir, m_fRoll);
	// Apply transformation against the RollMatrix
	D3DXVec3TransformCoord(&m_vecRight, &m_vecRight, &matRoll); 
	D3DXVec3TransformCoord(&m_vecUp, &m_vecUp, &matRoll); 


	//Create ViewMatrix
	D3DXMatrixIdentity(&m_matView);

	m_matView._11 = m_vecRight.x;
	m_matView._12 = m_vecUp.x;
	m_matView._13 = m_vecDir.x;

	m_matView._21 = m_vecRight.y;
	m_matView._22 = m_vecUp.y; 
	m_matView._23 = m_vecDir.y;

	m_matView._31 = m_vecRight.z;
	m_matView._32 = m_vecUp.z;
	m_matView._33 = m_vecDir.z;
	
	m_matView._41 = - D3DXVec3Dot(&m_vecPos, &m_vecRight); 
	m_matView._42 = - D3DXVec3Dot(&m_vecPos, &m_vecUp);
	m_matView._43 = - D3DXVec3Dot(&m_vecPos, &m_vecDir);


	// Send the View Matrix to the rendering device.
}

void
Camera::CalculateProjMatrix(float _fClientWidth, float _fClientHeight)
{
	float fAspect = _fClientWidth/_fClientHeight;
	//D3DXMatrixPerspectiveFovLH(&m_matProj, 0.25f*PI, fAspect, 1.0f, 10000.0f);

	D3DXMatrixOrthoLH(&m_matProj, _fClientWidth, _fClientHeight, 1.0f, 1000.0f);
}

void 
Camera::ResetCamera()
{
	// Set all matrices to identity.
	D3DXMatrixIdentity(&m_matView);
	D3DXMatrixIdentity(&m_matPreviousVP);

	ZeroMemory(&m_vecPos, sizeof(D3DXVECTOR3));
	m_vecUp = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	m_vecDir = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
	m_vecRight = D3DXVECTOR3(1.0f, 0.0f, 0.0f);

	//Acceleration/Velocity
	m_fMoveAccel = 0.0f;
	m_fMoveVel = 0.0f;
	m_fStrafeAccel = 0.0f;
	m_fStrafeVel = 0.0f;
	m_fFlyAccel = 0.0f;
	m_fFlyVel = 0.0f;

	m_fYawAccel = 0.0f;
	m_fYawVel = 0.0f;
	m_fPitchAccel = 0.0f;
	m_fPitchVel = 0.0f;
	m_fRollAccel = 0.0f;
	m_fRollVel = 0.0f;

	m_fPitch = 0.0f;
	m_fYaw = 0.0f;
	m_fRoll = 0.0f;

	//Force camera position
	m_vecPos.z = -100.0f;
}


void
Camera::Move(float _fDistance)
{
	m_fMoveVel += _fDistance;
}

void
Camera::Strafe(float _fDistance)
{
	m_fStrafeVel += _fDistance;
}

void
Camera::Fly(float _fDistance)
{
	m_fFlyVel += _fDistance;
}

void
Camera::Yaw(float _fAngle)
{
	m_fYawVel += _fAngle;
}

void
Camera::Pitch(float _fAngle)
{
	m_fPitchVel += _fAngle;
}

void
Camera::Roll(float _fAngle)
{
	m_fRollVel += _fAngle;
}

//Test
void
Camera::Move()
{
	m_vecPos += m_vecDir * m_fMoveVel;
}

void
Camera::Strafe()
{
	m_vecPos += m_vecRight * m_fStrafeVel;
}

void
Camera::Fly()
{
	m_vecPos += m_vecUp * m_fFlyVel;
}

void
Camera::Yaw()
{
	m_fYaw += m_fYawVel;
}

void
Camera::Pitch()
{
	m_fPitch += m_fPitchVel;
}

void
Camera::Roll()
{
	m_fRoll += m_fRollVel;
}

D3DXMATRIX* 
Camera::GetViewMatrix()
{
	return(&m_matView);
}

D3DXMATRIX* 
Camera::GetProjMatrix()
{
	return(&m_matProj);
}

D3DXVECTOR3* 
Camera::GetLookAt()
{
	return(&m_vecDir);
}

D3DXVECTOR3* 
Camera::GetPos()
{
	return(&m_vecPos);
}

void 
Camera::SetPreviousVP()
{
	D3DXMatrixMultiply(&m_matPreviousVP, &m_matView, &m_matProj);
}

D3DXMATRIX* 
Camera::GetPreviousVP()
{
	return(&m_matPreviousVP);
}