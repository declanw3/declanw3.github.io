#include "Utility.h"
#include "Shape.h"

#ifndef _TRIANGLE_H_
#define _TRIANGLE_H_

class Triangle : public Shape
{
public:
	Triangle();
	~Triangle();
	
	const bool Initialise(ID3D10Device* device, D3DXCOLOR _color, bool _bIndexed);
	void Draw(ID3D10Device* device);

protected:
private:

public:
protected:
private:
};

#endif //_TRIANGLE_H_