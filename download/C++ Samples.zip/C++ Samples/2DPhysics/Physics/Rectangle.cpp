#include "Rectangle.h"
#include "Vertex.h"

CRectangle::CRectangle()
:m_fWidth(1.0f)
,m_fHeight(1.0f)
{

}

CRectangle::CRectangle(const float _kfWidth, const float _kfHeight)
:m_fWidth(_kfWidth)
,m_fHeight(_kfHeight)
{

}

CRectangle::~CRectangle()
{

}

const bool
CRectangle::Initialise(ID3D10Device* device, D3DXCOLOR _color, bool _bIndexed)
{
	bool bSuccess = false;

	//Assign device
	md3dDevice = device;

	//Triangle mesh data
	m_iVertexCount = 6;
	m_iIndexCount = 4;


	//Rectangle verts
	float fWidth = static_cast<float>(m_fWidth / 2);
	float fHeight = static_cast<float>(m_fHeight / 2);

	//Create Vertex Buffer
	//Populate VertexData
	if(mVB == 0)
	{
		Vertex vertices[6] = {Vertex(D3DXVECTOR3(-fWidth, fHeight, 0.0f), _color), //Top left
								Vertex(D3DXVECTOR3(fWidth, fHeight, 0.0f), _color),//Top right
								Vertex(D3DXVECTOR3(fWidth, -fHeight, 0.0f), _color),//Bot right
								Vertex(D3DXVECTOR3(fWidth, -fHeight, 0.0f), _color),//Bot right
								Vertex(D3DXVECTOR3(-fWidth, -fHeight, 0.0f), _color), //Bot left
								Vertex(D3DXVECTOR3(-fWidth, fHeight, 0.0f), _color)};//Top left
		D3D10_BUFFER_DESC vbd;
		vbd.Usage = D3D10_USAGE_IMMUTABLE;
		vbd.ByteWidth = sizeof(Vertex) * m_iVertexCount;
		vbd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
		vbd.CPUAccessFlags = 0;
		vbd.MiscFlags = 0;
		D3D10_SUBRESOURCE_DATA vinitData;
		vinitData.pSysMem = vertices;
		HR(md3dDevice->CreateBuffer(&vbd, &vinitData, &mVB));
	}


	//Create the index buffer
	// Populate IndexData
	if(_bIndexed)
	{
		if(mIB == 0)
		{
			DWORD indices[4] = {0, //Triangle left leg
								1, //Triangle head
								2,
								3}; //Triangle right leg


			D3D10_BUFFER_DESC ibd;
			ibd.Usage = D3D10_USAGE_IMMUTABLE;
			ibd.ByteWidth = sizeof(DWORD) * m_iIndexCount;
			ibd.BindFlags = D3D10_BIND_INDEX_BUFFER;
			ibd.CPUAccessFlags = 0;
			ibd.MiscFlags = 0;
			D3D10_SUBRESOURCE_DATA iinitData;
			iinitData.pSysMem = indices;
			HR(md3dDevice->CreateBuffer(&ibd, &iinitData, &mIB));
		}
	}

	return(bSuccess);
}

void 
CRectangle::Draw(ID3D10Device* device)
{
    md3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shape::Draw(device);
}