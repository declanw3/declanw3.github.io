#include "Utility.h"
#include "Shape.h"

#ifndef __RECTANGLE_H__
#define __RECTANGLE_H__

class CRectangle : public Shape
{
public:
	CRectangle();
	CRectangle(const float _kfWidth, const float _kfHeight);
	~CRectangle();
	
	const bool Initialise(ID3D10Device* device, D3DXCOLOR _color, bool _bIndexed);
	void Draw(ID3D10Device* device);

protected:
private:

public:
protected:
private:
	float m_fWidth;
	float m_fHeight;
};

#endif //__RECTANGLE_H__