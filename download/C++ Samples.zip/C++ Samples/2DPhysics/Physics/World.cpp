#include "World.h"
#include "GameObject.h"
#include "Box2DObject.h"
#include "ContactListener.h"

const float g_kfBox2DScale = 10.0f;

World::World()
:m_world(0)
,m_kiMaxSceneObjects(30)
,m_pBox2DObjects(0)
,m_kiMaxRenderObjects(5)
,m_pRenderObjects(0)
,m_pContactListener(0)
,m_eActiveScene(SCENE_ONE)
,m_eActiveBird(GRUMPYBIRD_ONE)
,m_pGrumpyBirds(0)
,m_bGameOver(false)
,m_kiMaxEnemyBirds(3)
,m_iEnemyBirdCount(m_kiMaxEnemyBirds)
,m_eGameState(GAMESTATE_PLAYING)
{

}

World::~World()
{
	Deinitialise();
}

bool
World::Intialise(ID3D10Device* device)
{
	//Initialise world
	b2Vec2 gravity;
	gravity.Set(0.0f, -10.0f);
	m_world = new b2World(gravity);
	m_bomb = NULL;
	m_textLine = 30;
	m_mouseJoint = NULL;
	m_pointCount = 0;

	//m_destructionListener.test = this;
	//m_world->SetDestructionListener(&m_destructionListener);
	//m_world->SetContactListener(this);
	//m_world->SetDebugDraw(&m_debugDraw);
	
	m_bombSpawning = false;

	m_stepCount = 0;

	b2BodyDef bodyDef;
	m_groundBody = m_world->CreateBody(&bodyDef);

	memset(&m_maxProfile, 0, sizeof(b2Profile));
	memset(&m_totalProfile, 0, sizeof(b2Profile));	


	//Set object counts
	int iBox2DObjectCount = 0;
	int iRenderObjectCount = 0;

	//Initialise containers
	if(m_pBox2DObjects == 0)
	{
		m_pBox2DObjects = new Box2DObject*[m_kiMaxSceneObjects];

		for(int i = 0; i < m_kiMaxSceneObjects; ++i)
		{
			m_pBox2DObjects[i] = 0;
		}
	}
	if(m_pRenderObjects == 0)
	{
		m_pRenderObjects = new GameObject*[m_kiMaxRenderObjects];

		for(int i = 0; i < m_kiMaxRenderObjects; ++i)
		{
			m_pRenderObjects[i] = 0;
		}
	}
	if(m_pGrumpyBirds == 0)
	{
		m_pGrumpyBirds = new TGrumpyBird*[MAX_GRUMPYBIRD];

		for(int i = 0; i < MAX_GRUMPYBIRD; ++i)
		{
			m_pGrumpyBirds[i] = 0;
		}
	}
	if(m_pGrumpyBirds != 0)
	{
		for(int i = 0; i < MAX_GRUMPYBIRD; ++i)
		{
			m_pGrumpyBirds[i] = new TGrumpyBird();
		}	
	}


	//Initialise ContactListener
	m_pContactListener = new ContactListener();
	m_world->SetContactListener(m_pContactListener);
	static_cast<ContactListener*>(m_pContactListener)->Initialise(this);

	//Initialise Box2dObjects	
	InitialiseGrumpyBirds(device, iBox2DObjectCount);
	InitialiseWalls(device, iBox2DObjectCount);
	switch(m_eActiveScene)
	{
	case SCENE_ONE:
		{
			InitialiseScene1Objects(device, iBox2DObjectCount, iRenderObjectCount);
		}
		break;

	case SCENE_TWO:
		{
			InitialiseScene2Objects(device, iBox2DObjectCount, iRenderObjectCount);
		}
		break;

	default:break;
	}

	m_bGameOver = false;
	m_iEnemyBirdCount = m_kiMaxEnemyBirds;
	m_eGameState = GAMESTATE_PLAYING;

	return(false);
}

bool 
World::Deinitialise()
{
	if(m_pBox2DObjects != 0)
	{
		for(int i = 0; i < m_kiMaxSceneObjects; ++i)
		{
			if(m_pBox2DObjects[i] != 0)
			{
				m_world->DestroyBody( m_pBox2DObjects[i]->GetBody() );
				delete m_pBox2DObjects[i];
				m_pBox2DObjects[i] = 0;
			}
		}

		delete[] m_pBox2DObjects;
		m_pBox2DObjects = 0;
	}

	if(m_pRenderObjects != 0)
	{
		for(int i = 0; i < m_kiMaxRenderObjects; ++i)
		{
			if(m_pRenderObjects[i] != 0)
			{
				delete m_pRenderObjects[i];
				m_pRenderObjects[i] = 0;
			}
		}

		delete[] m_pRenderObjects;
		m_pRenderObjects = 0;
	}

	if(m_pContactListener != 0)
	{
		delete m_pContactListener;
		m_pContactListener = 0;
	}

	if(m_world != 0)
	{
		delete m_world;
		m_world = 0;
	}

	if(m_pGrumpyBirds != 0)
	{
		for(int i = 0; i < MAX_GRUMPYBIRD; ++i)
		{
			if(m_pGrumpyBirds[i] != 0)
			{
				delete m_pGrumpyBirds[i];
				m_pGrumpyBirds[i] = 0;
			}
		}

		delete[] m_pGrumpyBirds;
		m_pGrumpyBirds = 0;
	}

	m_eActiveBird = static_cast<EGrumpyBird>(INVALID_GRUMPYBIRD + 1);


	return(false);
}

void 
World::Update(float dt)
{
	m_world->Step(dt, 8, 2);
	SweepDeadBox2DObjects();

	if(m_eGameState == GAMESTATE_PLAYING)
	{
		CheckGameState();
	}

	if(m_pBox2DObjects != 0)
	{
		for(int i = 0; i < m_kiMaxSceneObjects; ++i)
		{
			if(GetBodyByID("SpringBox") != 0)
			{
				b2Body* _pSpringBox = GetBodyByID("SpringBox");

				b2Vec2 vec2SpringBoxVel = _pSpringBox->GetLinearVelocity();
				GetBodyByID("SpringBox")->SetLinearVelocity( b2Vec2(0.0f, vec2SpringBoxVel.y) );
			}

			if(m_pBox2DObjects[i] != 0)
			{
				m_pBox2DObjects[i]->Update(dt);
			}
		}
	}

	if(m_pRenderObjects != 0)
	{
		for(int i = 0; i < m_kiMaxRenderObjects; ++i)
		{
			if(m_pRenderObjects[i] != 0)
			{
				if( strcmp(m_pRenderObjects[i]->GetID(), "RopeJoint1") == 0 )
				{
					RenderLine(m_pRenderObjects[i], GetBodyByID("PivotBox"), GetBodyByID("SpinningBox"));
				}

				if( strcmp(m_pRenderObjects[i]->GetID(), "DistanceJoint1") == 0 )
				{
					RenderLine(m_pRenderObjects[i], GetBodyByID("StaticDistancePivot1"), GetBodyByID("SpringBox"));
				}

				m_pRenderObjects[i]->Update(dt);
			}
		}
	}
}

void 
World::Draw(ID3D10Device* device)
{

}

bool
World::InitialiseGrumpyBirds(ID3D10Device* device, int& _riBox2DObjectCount)
{
	b2BodyDef myBodyDef; 

	//GrumpyBird1
	myBodyDef.type = b2_dynamicBody;							//This will be a dynamic body
	myBodyDef.position.Set(-75, -45);	
	myBodyDef.userData = "GrumpyBird";

	b2CircleShape circleShape;
	float fRadius = 2.0f;
	circleShape.m_radius = fRadius;

	b2FixtureDef circleFixtureDef;
	circleFixtureDef.shape = &circleShape;
	circleFixtureDef.density = 0.85f;
	circleFixtureDef.restitution = 0.15f;
	circleFixtureDef.friction = 0.5f;
	circleFixtureDef.userData = "GrumpyBird1";

	Box2DObject* newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("GrumpyBird1");
	newBox2DObject->AddGameObjectShape(device, SHAPE_CIRCLE, WHITE);
	newBox2DObject->GetGameObject()->SetScale(fRadius * g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(circleFixtureDef);
	newBox2DObject->GetBody()->SetActive(false);
	newBox2DObject->GetGameObject()->SetActive(true);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//GrumpyBird2
	myBodyDef.type = b2_dynamicBody;							//This will be a dynamic body
	myBodyDef.position.Set(-75, -45);	
	myBodyDef.userData = "GrumpyBird";

	fRadius = 3.0f;
	circleShape.m_radius = fRadius;

	circleFixtureDef.shape = &circleShape;
	circleFixtureDef.density = 0.5f;
	circleFixtureDef.restitution = 0.9f;
	circleFixtureDef.friction = 0.5f;
	circleFixtureDef.userData = "GrumpyBird2";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("GrumpyBird2");
	newBox2DObject->AddGameObjectShape(device, SHAPE_CIRCLE, BLUE);
	newBox2DObject->GetGameObject()->SetScale(fRadius * g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(circleFixtureDef);
	newBox2DObject->GetBody()->SetActive(false);
	newBox2DObject->GetGameObject()->SetActive(false);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//GrumpyBird3
	myBodyDef.type = b2_dynamicBody;							//This will be a dynamic body
	myBodyDef.position.Set(-75, -45);	
	myBodyDef.userData = "GrumpyBird";

	fRadius = 6.0f;
	circleShape.m_radius = fRadius;

	circleFixtureDef.shape = &circleShape;
	circleFixtureDef.density = 0.15f;
	circleFixtureDef.restitution = 0.65f;
	circleFixtureDef.friction = 0.85f;
	circleFixtureDef.userData = "GrumpyBird3";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("GrumpyBird3");
	newBox2DObject->AddGameObjectShape(device, SHAPE_CIRCLE, CYAN);
	newBox2DObject->GetGameObject()->SetScale(fRadius * g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(circleFixtureDef);
	newBox2DObject->GetBody()->SetActive(false);
	newBox2DObject->GetGameObject()->SetActive(false);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	return(false);
}

bool
World::InitialiseWalls(ID3D10Device* device, int& _riBox2DObjectCount)
{
	//Top wall
	b2BodyDef myBodyDef; 
	myBodyDef.type = b2_staticBody;							//This will be a static body
	myBodyDef.position.Set(0, 60.0f);	
	myBodyDef.userData = "RigidBody";

	b2PolygonShape rectangleShape;
	float fWidth = 100.0f;
	float fHeight = 1.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);

	b2FixtureDef rectangleFixtureDef;
	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.userData = "TopWall";

	Box2DObject* newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("TopWall");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//Bot wall
	fWidth = 100.0f;
	fHeight = 1.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(0, -60.0f);	

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.userData = "BotWall";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("BotWall");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//Left wall
	fWidth = 1.0f;
	fHeight = 60.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(-100, 0);	

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.userData = "LeftWall";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("LeftWall");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//Right wall
	fWidth = 1.0f;
	fHeight = 60.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(100, 0);	

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.userData = "RightWall";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("RightWall");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	return(false);
}

bool
World::InitialiseScene1Objects(ID3D10Device* device, int& _riBox2DObjectCount, int& _riRenderObjectCount)
{
	//PivotBox
	b2BodyDef myBodyDef; 
	myBodyDef.type = b2_staticBody;							//This will be a static body
	myBodyDef.position.Set(0, 0.0f);	

	b2PolygonShape rectangleShape;
	float fWidth = 3.0f;
	float fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);

	b2FixtureDef rectangleFixtureDef;
	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.userData = "PivotBox";

	Box2DObject* newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("PivotBox");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//SpinningBox
	fWidth = 5.0f;
	fHeight = 5.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(30, 30);	
	myBodyDef.angularVelocity = 2.0f;

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.userData = "SpinningBox";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("SpinningBox");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//RopeJoint
	b2RopeJointDef ropeJointDef;
	ropeJointDef.bodyA = GetBodyByID("PivotBox");
	ropeJointDef.bodyB = GetBodyByID("SpinningBox");
	ropeJointDef.localAnchorA = b2Vec2(0,0);
	ropeJointDef.localAnchorB = b2Vec2(0,0);
	ropeJointDef.maxLength = 50;
	ropeJointDef.collideConnected = true;
	m_world->CreateJoint(&ropeJointDef);

	GameObject* newRenderObject = new GameObject();
	newRenderObject->SetID("RopeJoint1");
	newRenderObject->InitialiseShape(device, SHAPE_LINE, BLACK);

	m_pRenderObjects[_riRenderObjectCount++] = newRenderObject;



	//PivotCircle
	myBodyDef.type = b2_staticBody;							//This will be a static body
	myBodyDef.position.Set(55, -55);
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	b2CircleShape circleShape;
	float fRadius = 2.0f;
	circleShape.m_radius = fRadius;

	b2FixtureDef circleFixtureDef;
	circleFixtureDef.shape = &circleShape;
	circleFixtureDef.density = 1.0f;
	circleFixtureDef.userData = "PivotCircle";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("PivotCircle");
	newBox2DObject->AddGameObjectShape(device, SHAPE_CIRCLE, BLACK);
	newBox2DObject->GetGameObject()->SetScale(fRadius * g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(circleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//LeverBox
	fWidth = 25.0f;
	fHeight = 1.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(60, -50);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 0.15f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "LeverBox";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("LeverBox");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//RevoluteJoint
	b2RevoluteJointDef revoluteJointDef;
	revoluteJointDef.Initialize(GetBodyByID("PivotCircle"),
								GetBodyByID("LeverBox"),
								GetBodyByID("PivotCircle")->GetWorldCenter());
	//revoluteJointDef.maxMotorTorque = 1.0;
	//revoluteJointDef.enableMotor = true;
 
	m_world->CreateJoint(&revoluteJointDef);



	//FallingBox
	fWidth = 6.0f;
	fHeight = 6.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(40, 50);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.1f;
	rectangleFixtureDef.userData = "FallingBox";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallingBox");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FlingBox
	fWidth = 2.0f;
	fHeight = 2.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(70, -40);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.9f;
	rectangleFixtureDef.userData = "FlingBox";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FlingBox");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//StaticDistancePivot1
	fWidth = 2.0f;
	fHeight = 2.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(-70, 40);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.0f;
	rectangleFixtureDef.userData = "StaticDistancePivot1";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("StaticDistancePivot1");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//SpringBox
	fWidth = 20.0f;
	fHeight = 2.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(-70, 20);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 0.15f;
	rectangleFixtureDef.friction = 0.0f;
	rectangleFixtureDef.userData = "SpringBox";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("SpringBox");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);
	newBox2DObject->GetBody()->SetFixedRotation(true);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//SpringDistanceJoint1
	b2DistanceJointDef distanceJointDef;
	distanceJointDef.Initialize(GetBodyByID("StaticDistancePivot1"),
								GetBodyByID("SpringBox"),
								GetBodyByID("StaticDistancePivot1")->GetWorldCenter(),
								GetBodyByID("SpringBox")->GetWorldCenter());
	distanceJointDef.length = 35;
	distanceJointDef.frequencyHz = 0.25f;
	distanceJointDef.dampingRatio = 0.05f;
	distanceJointDef.collideConnected = true;

	m_world->CreateJoint(&distanceJointDef);

	newRenderObject = new GameObject();
	newRenderObject->SetID("DistanceJoint1");
	newRenderObject->InitialiseShape(device, SHAPE_LINE, BLACK);

	m_pRenderObjects[_riRenderObjectCount++] = newRenderObject;



	//EnemyBird1
	//Set each vertex of polygon in an array
	const float fTriScale = 3.0f;
	const int kiTriVertCount = 3;
	b2Vec2 vertices[kiTriVertCount];
	vertices[0].Set(fTriScale, -fTriScale);
	vertices[1].Set(0.0f, fTriScale);
	vertices[2].Set(-fTriScale, -fTriScale);
  
	b2PolygonShape polygonShape;
	polygonShape.Set(vertices, kiTriVertCount); //pass array to the shape
  
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(-70, 30);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "EnemyBird";
	
	b2FixtureDef polygonFixtureDef;
	polygonFixtureDef.shape = &polygonShape; //change the shape of the fixture
	polygonFixtureDef.density = 1.0f;
	polygonFixtureDef.friction = 0.25f;
	polygonFixtureDef.userData = "EnemyBird1";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("EnemyBird1");
	newBox2DObject->AddGameObjectShape(device, SHAPE_TRIANGLE, RED);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale * fTriScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(polygonFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;

	

	//EnemyBird2
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, 50);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "EnemyBird";

	polygonFixtureDef.userData = "EnemyBird2";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("EnemyBird2");
	newBox2DObject->AddGameObjectShape(device, SHAPE_TRIANGLE, RED);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale * fTriScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(polygonFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//EnemyBird3
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(90, -20);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "EnemyBird";
	
	polygonFixtureDef.userData = "EnemyBird3";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("EnemyBird3");
	newBox2DObject->AddGameObjectShape(device, SHAPE_TRIANGLE, RED);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale * fTriScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(polygonFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//GlassWall
	fWidth = 1.0f;
	fHeight = 15.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(-15, 20);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "GlassWall";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 0.15f;
	rectangleFixtureDef.friction = 0.0f;
	rectangleFixtureDef.userData = "GlassWall";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("GlassWall");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLUE, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//RigidWall
	fWidth = 1.0f;
	fHeight = 15.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(15, 20);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = 0;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.density = 0.15f;
	rectangleFixtureDef.friction = 0.0f;
	rectangleFixtureDef.userData = "RigidWall";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("RigidWall");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;


	return(false);
}

bool
World::InitialiseScene2Objects(ID3D10Device* device, int& _riBox2DObjectCount, int& _riRenderObjectCount)
{
	//FallBox1
	b2BodyDef myBodyDef; 
	myBodyDef.type = b2_dynamicBody;							//This will be a static body
	myBodyDef.position.Set(0, 50);	
	myBodyDef.userData = "RigidBody";

	b2PolygonShape rectangleShape;
	float fWidth = 3.0f;
	float fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);

	b2FixtureDef rectangleFixtureDef;
	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox1";

	Box2DObject* newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox1");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox2
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, 40);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox2";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox2");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox3
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, 30);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox3";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox3");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox4
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, 20);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox4";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox4");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox5
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, 10);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox5";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox5");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox6
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, 0);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox6";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox6");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox7
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, -10);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox7";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox7");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox8
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, -20);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox8";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox8");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox9
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, -30);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox9";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox9");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox10
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, -40);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox10";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox10");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//FallBox11
	fWidth = 3.0f;
	fHeight = 3.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, -50);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.75f;
	rectangleFixtureDef.density = 0.5f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "FallBox11";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("FallBox11");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//PillarBox1
	fWidth = 1.0f;
	fHeight = 50.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(-20, -10);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.5f;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "PillarBox1";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("PillarBox1");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//StaticBox1
	fWidth = 10.0f;
	fHeight = 1.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(30, 20);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "RigidBody";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.5f;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "StaticBox1";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("StaticBox1");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//StaticBox2
	fWidth = 10.0f;
	fHeight = 1.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(90, 40);	
	myBodyDef.angularVelocity = 0.0f;
	//myBodyDef.userData = "GlassWall";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.5f;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "StaticBox2";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("StaticBox2");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLACK, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//GlassWall1
	fWidth = 1.0f;
	fHeight = 10.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(50, -50);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "GlassWall";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.5f;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "GlassWall1";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("GlassWall1");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLUE, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//GlassWall2
	fWidth = 1.0f;
	fHeight = 10.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(70, -50);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "GlassWall";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.5f;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "GlassWall2";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("GlassWall2");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLUE, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;
	


	//GlassWall3
	fWidth = 10.0f;
	fHeight = 1.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(60, -35);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "GlassWall";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.5f;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "GlassWall3";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("GlassWall3");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLUE, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;




	//GlassWall4
	fWidth = 1.0f;
	fHeight = 1.0f;
	rectangleShape.SetAsBox(fWidth, fHeight);
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(60, -20);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "GlassWall";

	rectangleFixtureDef.shape = &rectangleShape;
	rectangleFixtureDef.restitution = 0.5f;
	rectangleFixtureDef.density = 1.0f;
	rectangleFixtureDef.friction = 0.5f;
	rectangleFixtureDef.userData = "GlassWall4";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("GlassWall4");
	newBox2DObject->AddGameObjectShape(device, SHAPE_RECTANGLE, BLUE, fWidth, fHeight);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(rectangleFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//EnemyBird1
	//Set each vertex of polygon in an array
	const float fTriScale = 3.0f;
	const int kiTriVertCount = 3;
	b2Vec2 vertices[kiTriVertCount];
	vertices[0].Set(fTriScale, -fTriScale);
	vertices[1].Set(0.0f, fTriScale);
	vertices[2].Set(-fTriScale, -fTriScale);
  
	b2PolygonShape polygonShape;
	polygonShape.Set(vertices, kiTriVertCount); //pass array to the shape
  
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(0, 60);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "EnemyBird";
	
	b2FixtureDef polygonFixtureDef;
	polygonFixtureDef.shape = &polygonShape; //change the shape of the fixture
	polygonFixtureDef.density = 1.0f;
	polygonFixtureDef.friction = 0.25f;
	polygonFixtureDef.userData = "EnemyBird1";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("EnemyBird1");
	newBox2DObject->AddGameObjectShape(device, SHAPE_TRIANGLE, RED);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale * fTriScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(polygonFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;

	

	//EnemyBird2
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(60, -45);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "EnemyBird";

	polygonFixtureDef.userData = "EnemyBird2";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("EnemyBird2");
	newBox2DObject->AddGameObjectShape(device, SHAPE_TRIANGLE, RED);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale * fTriScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(polygonFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	//EnemyBird3
	myBodyDef.type = b2_dynamicBody;
	myBodyDef.position.Set(90, 50);	
	myBodyDef.angularVelocity = 0.0f;
	myBodyDef.userData = "EnemyBird";

	polygonFixtureDef.userData = "EnemyBird3";

	newBox2DObject = new Box2DObject();
	newBox2DObject->Initialise();
	newBox2DObject->SetID("EnemyBird3");
	newBox2DObject->AddGameObjectShape(device, SHAPE_TRIANGLE, RED);
	newBox2DObject->GetGameObject()->SetScale(g_kfBox2DScale * fTriScale);
	newBox2DObject->AddBody(m_world, myBodyDef);
	newBox2DObject->AddFixture(polygonFixtureDef);

	m_pBox2DObjects[_riBox2DObjectCount++] = newBox2DObject;



	return(false);
}

void
World::RenderLine(GameObject* _pGameObject, b2Body* _pBody1, b2Body* _pBody2)
{
	if(_pGameObject != 0)
	{
		if(_pBody1 != 0)
		{
			if(_pBody2 != 0)
			{
				b2Vec2 vec2Body1Pos = _pBody1->GetPosition();
				b2Vec2 vec2Body2Pos = _pBody2->GetPosition();
				b2Vec2 vec2Distance = vec2Body2Pos - vec2Body1Pos;

				D3DXVECTOR3 vec3StartPos = D3DXVECTOR3(vec2Body1Pos.x, vec2Body1Pos.y, 0.0f);
				D3DXVec3Scale(&vec3StartPos, &vec3StartPos, g_kfPositionScale);
				float fAngle = AngleBetweenVec3( D3DXVECTOR3(0.0f, 1.0f, 0.0f), 
												D3DXVECTOR3(vec2Body2Pos.x - vec2Body1Pos.x,
															vec2Body2Pos.y - vec2Body1Pos.y,
												0.0f) );

				if(vec2Body2Pos.x > 0)
				{
					fAngle = (2 * PI) - fAngle;
				}

				_pGameObject->SetPosition(vec3StartPos);
				_pGameObject->SetRoll(fAngle);
				_pGameObject->SetScale( vec2Distance.Length() * g_kfBox2DScale );
			}
		}
	}
}

const int 
World::GetMaxBox2DObjects()
{
	return(m_kiMaxSceneObjects);
}

Box2DObject*
World::GetBox2DObject(const int _kiIndex)
{
	Box2DObject* pBox2DObject = 0;

	if( (_kiIndex > -1) && (_kiIndex < m_kiMaxSceneObjects) )
	{
		if(m_pBox2DObjects != 0)
		{
			if(m_pBox2DObjects[_kiIndex] != 0)
			{
				pBox2DObject = m_pBox2DObjects[_kiIndex];
			}
		}
	}

	return(pBox2DObject);
}

Box2DObject* 
World::GetBox2DObjectByID(const char* _kcID)
{
	Box2DObject* pBox2DObject = 0;

	if(m_pBox2DObjects != 0)
	{
		for(int i = 0; i < m_kiMaxSceneObjects; ++i)
		{
			if(m_pBox2DObjects[i] != 0)
			{
				if( strcmp(m_pBox2DObjects[i]->GetID(), _kcID) == 0 )
				{
					pBox2DObject = m_pBox2DObjects[i];

					break;
				}
			}
		}
	}

	return(pBox2DObject);
}

b2Body*
World::GetBodyByID(const char* _kcID)
{
	b2Body* pBody = 0;

	if(m_pBox2DObjects != 0)
	{
		for(int i = 0; i < m_kiMaxSceneObjects; ++i)
		{
			if(m_pBox2DObjects[i] != 0)
			{
				if( strcmp(m_pBox2DObjects[i]->GetID(), _kcID) == 0 )
				{
					pBody = m_pBox2DObjects[i]->GetBody();

					break;
				}
			}
		}
	}

	return(pBody);
}

const int 
World::GetMaxRenderObjects()
{
	return(m_kiMaxRenderObjects);
}


GameObject*
World::GetRenderObject(const int _kiIndex)
{
	GameObject* pRenderObject = 0;

	if( (_kiIndex > -1) && (_kiIndex < m_kiMaxRenderObjects) )
	{
		if(m_pRenderObjects != 0)
		{
			if(m_pRenderObjects[_kiIndex] != 0)
			{
				pRenderObject = m_pRenderObjects[_kiIndex];
			}
		}
	}

	return(pRenderObject);
}

const bool 
World::DestroyBox2DObject(const char* _kcID)
{
	bool bSuccess = false;

	if(m_pBox2DObjects != 0)
	{
		for(int i = 0; i < m_kiMaxSceneObjects; ++i)
		{
			if(m_pBox2DObjects[i] != 0)
			{
				if( strcmp(m_pBox2DObjects[i]->GetID(), _kcID) == 0 )
				{
					m_pBox2DObjects[i]->GetBody()->SetUserData("DESTROY");

					bSuccess = true;

					break;
				}
			}
		}
	}

	return(bSuccess);
}

void
World::SweepDeadBox2DObjects()
{
	if(m_pBox2DObjects != 0)
	{
		for(int i = 0; i < m_kiMaxSceneObjects; ++i)
		{
			if(m_pBox2DObjects[i] != 0)
			{
				if(m_pBox2DObjects[i]->GetBody()->GetUserData() != 0)
				{
					char* pcID = reinterpret_cast<char*>(m_pBox2DObjects[i]->GetBody()->GetUserData());
					if( strcmp(pcID, "DESTROY") == 0 )
					{
						m_world->DestroyBody( m_pBox2DObjects[i]->GetBody() );
						delete m_pBox2DObjects[i];
						m_pBox2DObjects[i] = 0;
					}
				}
			}
		}
	}
}

const EScene 
World::GetActiveScene()
{
	return(m_eActiveScene);
}

void 
World::SetActiveScene(const EScene _eActiveScene)
{
	m_eActiveScene = _eActiveScene;
}

const EGrumpyBird 
World::GetActiveBird()
{
	return(m_eActiveBird);
}

void 
World::SetActiveBird(const EGrumpyBird _eActiveBird)
{
	m_eActiveBird = _eActiveBird;
}

TGrumpyBird* 
World::GetGrumpyBird(const int _kiIndex)
{
	TGrumpyBird* pGrumpyBird = 0;

	if( (_kiIndex > INVALID_GRUMPYBIRD) && (_kiIndex < MAX_GRUMPYBIRD) )
	{
		pGrumpyBird = m_pGrumpyBirds[_kiIndex];
	}

	return(pGrumpyBird);
}

void
World::IncrementActiveBird()
{
	GameObject* pBirdObject = 0;


	if(m_eActiveBird == MAX_GRUMPYBIRD - 1)
	{
		m_eActiveBird = static_cast<EGrumpyBird>(INVALID_GRUMPYBIRD + 1);
	}
	else
	{
		m_eActiveBird = static_cast<EGrumpyBird>(m_eActiveBird + 1);
	}


	GetBox2DObjectByID("GrumpyBird1")->GetGameObject()->SetActive(false);
	GetBox2DObjectByID("GrumpyBird2")->GetGameObject()->SetActive(false);
	GetBox2DObjectByID("GrumpyBird3")->GetGameObject()->SetActive(false);


	for(int i = 0; i < MAX_GRUMPYBIRD; ++i)
	{
		if(m_pGrumpyBirds[i]->bFired)
		{
			switch(i)
			{
				case GRUMPYBIRD_ONE:
					{
						GetBox2DObjectByID("GrumpyBird1")->GetGameObject()->SetActive(true);
					}
					break;

				case GRUMPYBIRD_TWO:
					{
						GetBox2DObjectByID("GrumpyBird2")->GetGameObject()->SetActive(true);
					}
					break;

				case GRUMPYBIRD_THREE:
					{
						GetBox2DObjectByID("GrumpyBird3")->GetGameObject()->SetActive(true);
					}
					break;

				default:break;
			}
		}
	}


	switch(m_eActiveBird)
	{
		case GRUMPYBIRD_ONE:
			{
				pBirdObject = GetBox2DObjectByID("GrumpyBird1")->GetGameObject();
			}
			break;

		case GRUMPYBIRD_TWO:
			{
				pBirdObject = GetBox2DObjectByID("GrumpyBird2")->GetGameObject();
			}
			break;

		case GRUMPYBIRD_THREE:
			{
				pBirdObject = GetBox2DObjectByID("GrumpyBird3")->GetGameObject();
			}
			break;

		default:break;
	}


	pBirdObject->SetActive(true);
}

void 
World::DecrementEnemyCount()
{
	if(m_iEnemyBirdCount != 0)
	{
		--m_iEnemyBirdCount;
	}
}

const bool
World::CheckGameState()
{
	bool bChangedState = false;

	int iFiredBirds = 0;
	for(int i = 0; i < MAX_GRUMPYBIRD; ++i)
	{
		if(m_pGrumpyBirds[i]->bFired)
		{
			++iFiredBirds;
		}
		else
		{
			break;
		}
	}

	int iStaticBirds = 0;
	if(iFiredBirds == MAX_GRUMPYBIRD)
	{
		//Check state
		if(m_iEnemyBirdCount == 0)
		{
			//Win
			bChangedState = true;
			m_eGameState = GAMESTATE_WIN;
		}
		else
		{
			for(int i = 0; i < MAX_GRUMPYBIRD; ++i)
			{
				switch( i )
				{
					case GRUMPYBIRD_ONE:
						{
							if( GetBodyByID("GrumpyBird1")->GetLinearVelocity().LengthSquared() > 0)
							{
								break;
							}
							else
							{
								++iStaticBirds;
							}
						}
						break;

					case GRUMPYBIRD_TWO:
						{
							if( GetBodyByID("GrumpyBird2")->GetLinearVelocity().LengthSquared() > 0)
							{
								break;
							}
							else
							{
								++iStaticBirds;
							}
						}
						break;

					case GRUMPYBIRD_THREE:
						{
							if( GetBodyByID("GrumpyBird3")->GetLinearVelocity().LengthSquared() > 0)
							{
								break;
							}
							else
							{
								++iStaticBirds;
							}
						}
						break;

					default:break;
				}
			}

			if(iStaticBirds == MAX_GRUMPYBIRD)
			{
				//Lose
				bChangedState = true;
				m_eGameState = GAMESTATE_LOSE;
			}
		}
	}

	return(bChangedState);
}

void 
World::SetGameState(const EGameState _eGameState)
{
	m_eGameState = _eGameState;
}

const EGameState
World::GetGameState()
{
	return(m_eGameState);
}