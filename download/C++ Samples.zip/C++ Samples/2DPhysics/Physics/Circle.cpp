#include "Circle.h"
#include "Vertex.h"

Circle::Circle()
: m_iDivisions(0)
{

}

Circle::Circle(int _iDivisions)
: m_iDivisions(_iDivisions)
{

}

Circle::~Circle()
{

}

const bool
Circle::Initialise(ID3D10Device* device, D3DXCOLOR _color, bool _bIndexed)
{
	bool bSuccess = false;

	if(m_iDivisions > 0)
	{
		//Assign device
		md3dDevice = device;

		//Triangle mesh data
		m_iVertexCount = m_iDivisions;
		m_iIndexCount = m_iDivisions;

		//Create Vertex Buffer
		//Populate VertexData
		if(mVB == 0)
		{
			Vertex* vertices = 0;
			vertices = new Vertex[m_iDivisions];
			if(vertices != 0)
			{
				for(int i = 0; i < m_iDivisions; ++i)
				{
					D3DXVECTOR3 vecStart = D3DXVECTOR3(0.0f, 0.5f, 0.0f);
					
					float fSin = sinf( ((2 * PI) / m_iDivisions) * i );
					float fCos = cosf( ((2 * PI) / m_iDivisions) * i );

					// Translate point back to origin:
					D3DXVECTOR3 vecOrigin = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
					vecStart.x -= vecOrigin.x;
					vecStart.y -= vecOrigin.y;

					// rotate point
					float fNewX = vecStart.x * fCos - vecStart.y * fSin;
					float fNewY = -vecStart.x * fSin + vecStart.y * fCos;

					// translate point back:
					vecStart.x = fNewX + vecOrigin.x;
					vecStart.y = fNewY + vecOrigin.y;

					vertices[i] = Vertex(vecStart, _color);
				}

				D3D10_BUFFER_DESC vbd;
				vbd.Usage = D3D10_USAGE_IMMUTABLE;
				vbd.ByteWidth = sizeof(Vertex) * m_iVertexCount;
				vbd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
				vbd.CPUAccessFlags = 0;
				vbd.MiscFlags = 0;
				D3D10_SUBRESOURCE_DATA vinitData;
				vinitData.pSysMem = vertices;
				HR(md3dDevice->CreateBuffer(&vbd, &vinitData, &mVB));

				delete[] vertices;
				vertices = 0;
			}
		}


		//Create the index buffer
		// Populate IndexData
		if(_bIndexed)
		{
			if(mIB == 0)
			{
				DWORD* indices = 0;
				indices = new DWORD[m_iDivisions];
				if(indices != 0)
				{
					for(int i = 0; i < m_iDivisions; ++i)
					{
						indices[i] = i;
					}


					D3D10_BUFFER_DESC ibd;
					ibd.Usage = D3D10_USAGE_IMMUTABLE;
					ibd.ByteWidth = sizeof(DWORD) * m_iIndexCount;
					ibd.BindFlags = D3D10_BIND_INDEX_BUFFER;
					ibd.CPUAccessFlags = 0;
					ibd.MiscFlags = 0;
					D3D10_SUBRESOURCE_DATA iinitData;
					iinitData.pSysMem = indices;
					HR(md3dDevice->CreateBuffer(&ibd, &iinitData, &mIB));

					delete[] indices;
					indices = 0;
				}
			}
		}
	}

	return(bSuccess);
}

void 
Circle::Draw(ID3D10Device* device)
{
    md3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_LINESTRIP);

	Shape::Draw(device);
}