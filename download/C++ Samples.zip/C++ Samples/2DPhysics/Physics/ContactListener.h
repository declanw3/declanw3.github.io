#ifndef __CONTACTLISTENER_H__
#define __CONTACTLISTENER_H__

#include <Box2D\Box2D.h>

class World;
class ContactListener : public b2ContactListener
{
public:
	ContactListener();
	~ContactListener();

	const bool Initialise(World* _pWorldRef);
    virtual void BeginContact(b2Contact* contact);
    virtual void EndContact(b2Contact* contact);
    virtual void PreSolve(b2Contact* contact, const b2Manifold* oldManifold);    
    virtual void PostSolve(b2Contact* contact, const b2ContactImpulse* impulse);

protected:
private:

public:
protected:
private:
	World* m_pWorldRef;
};

#endif //__CONTACTLISTENER_H__