#include "Utility.h"
#include "Shape.h"

#ifndef _CIRCLE_H_
#define _CIRCLE_H_

class Circle : public Shape
{
public:
	Circle();
	Circle(int _iDivisions);
	~Circle();
	
	const bool Initialise(ID3D10Device* device, D3DXCOLOR _color, bool _bIndexed);
	void Draw(ID3D10Device* device);

protected:
private:

public:
protected:
private:
	int m_iDivisions;
};

#endif //_CIRCLE_H_